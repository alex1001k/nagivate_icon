"""
Оркестратор: указываете ОДИН источник данных — дальше вся цепочка (роли колонок,
связи, аномалии, план/факт, бриф) отрабатывает автоматически. Все промежуточные
и итоговые файлы автоматически называются по имени источника и складываются
в отдельную папку для этого источника.

ГЛАВНАЯ ПЕРЕМЕННАЯ — ИСТОЧНИК:
    --input   Путь к файлу-источнику (CSV/Excel). Именно отсюда берётся имя,
              которое подставляется во ВСЕ последующие файлы результатов
              и в имя папки.

КАК ТЕПЕРЬ УСТРОЕН ПОИСК ОТКЛОНЕНИЙ (два независимых слоя, не "или/или"):

  1) СТАТИСТИЧЕСКИЙ МЕТОД (--anomaly-method) — chronos / var / none / auto.
     "auto" (по умолчанию) определяется КОДОМ, не LLM: скрипт сам считает,
     сколько периодов истории реально доступно на показатель, и выбирает
     chronos (устойчивее на короткой истории) или отключает статистику
     вовсе (none), если периодов слишком мало даже для Chronos.

  2) ПЛАН/ФАКТ (--check-plan, по умолчанию включено) — если в column_roles.csv
     есть роль "plan_value", find_plan_deviations.py запускается ВСЕГДА,
     ДОПОЛНИТЕЛЬНО к статистическому методу, а не вместо него. План не требует
     длинной истории, поэтому имеет смысл проверять его всегда, когда он есть.

Оба источника отклонений (если оба сработали) передаются в generate_brief.py
одновременно — LLM видит и то, и другое сразу.

ЗАПУСК — с рабочим --api-base (полностью автоматически):
    python run_pipeline.py --input fact_pokazateli.csv \\
        --api-base http://34.56.56.65:8394/v1 --api-key ВАШ_КЛЮЧ

ЗАПУСК — без API (ручной копипаст на двух шагах):
    python run_pipeline.py --input fact_pokazateli.csv

Параметры:
    --input                 источник данных (CSV/Excel) — главная переменная пайплайна
    --work-dir               базовая папка (по умолчанию "./runs")
    --column-roles           (опционально) свой путь к файлу ролей колонок
    --anomaly-method         chronos | var | none | auto (по умолчанию auto)
    --min-periods-for-stats  при auto: ниже этого числа периодов статистика отключается
                             совсем (по умолчанию 6)
    --check-plan             включает проверку план/факт, если роль есть (по умолчанию True)
    --no-check-plan          отключить проверку план/факт полностью
    --recent-months          для плана: сколько последних периодов проверять (по умолчанию 3)
    --deviation-threshold    для плана: отклонение, считающееся крупным (по умолчанию 0.1)
    --max-sane-deviation     для плана: потолок правдоподобия (по умолчанию 5.0 = 500%)
    --top-plan-deviations    сколько отклонений от плана включать в бриф (по умолчанию 20)
    --top-anomalies          сколько статистических аномалий включать в бриф (по умолчанию 10)
    --embed-model            путь/имя модели эмбеддингов
    --chronos-model          путь/имя модели Chronos
    --context-length         сколько периодов видит Chronos (по умолчанию 6)
    --check-last-n           проверять только последние N периодов для Chronos/VAR (по умолчанию 3)
    --api-base               адрес API вашей LLM
    --api-key                API-ключ/токен
    --model-name             имя модели для запроса (по умолчанию "default")
    --sep                    разделитель CSV источника
"""

import argparse
import os
import re
import subprocess
import sys

import pandas as pd


def sanitize_name(name: str) -> str:
    name = re.sub(r"[^\w\-.]+", "_", name, flags=re.UNICODE)
    return name.strip("_") or "source"


def load_column_roles(path: str) -> dict:
    """Возвращает {роль: [список колонок]} — теперь МОЖЕТ быть несколько колонок
    на одну роль (например, несколько ролей "unit"/"category" — продукт, юнит,
    трайб — их комбинация и образует уникальный ряд для анализа)."""
    df = pd.read_csv(path, sep=";", encoding="utf-8-sig")
    roles = {}
    for _, row in df.iterrows():
        roles.setdefault(row["role"], []).append(row["column"])
    return roles


def read_input_auto(path: str, sep):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xls"):
        return pd.read_excel(path)
    if sep:
        return pd.read_csv(path, sep=sep, encoding="utf-8-sig")
    for candidate in (";", ","):
        df = pd.read_csv(path, sep=candidate, encoding="utf-8-sig")
        if df.shape[1] > 1:
            return df
    return df


def recommend_stat_method(input_path, sep, group_cols_list, metric_col, date_col, min_periods):
    """Определяет КОДОМ (не LLM), стоит ли вообще запускать статистический метод
    поиска аномалий, и если да — какой. Основано на том, сколько реально
    периодов истории доступно на показатель — это просто подсчёт дат,
    не требующий понимания смысла данных, поэтому LLM тут не нужна.
    """
    df = read_input_auto(input_path, sep)
    valid_group_cols = [c for c in group_cols_list if c in df.columns]
    group_cols = valid_group_cols + [metric_col] if valid_group_cols else [metric_col]
    if metric_col not in df.columns or date_col not in df.columns:
        return "chronos", None  # не смогли посчитать - безопасный дефолт

    counts = df.groupby(group_cols)[date_col].nunique()
    median_periods = counts.median()

    if median_periods < min_periods:
        return "none", median_periods
    return "chronos", median_periods


def run_step(description: str, cmd: list):
    print(f"\n{'='*70}\n{description}\n{'='*70}", file=sys.stderr)
    print("Команда:", " ".join(cmd), file=sys.stderr)
    result = subprocess.run(cmd, text=True)
    if result.returncode != 0:
        print(f"\nОШИБКА: шаг '{description}' завершился с кодом {result.returncode}. "
              f"Пайплайн остановлен.", file=sys.stderr)
        sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True)
    parser.add_argument("--work-dir", default="./runs")
    parser.add_argument("--column-roles", default=None)

    parser.add_argument("--anomaly-method", choices=["chronos", "var", "none", "auto"], default="auto",
                         help="статистический метод. 'auto' - определяется кодом по объёму истории")
    parser.add_argument("--min-periods-for-stats", type=int, default=None,
                         help="при auto: ниже этого числа периодов статистика отключается совсем. "
                              "По умолчанию вычисляется как context-length + check-last-n — тот же "
                              "технический минимум, что реально требует find_chronos_anomalies.py, "
                              "чтобы не получалось противоречие 'auto решил, что данных хватает, "
                              "а сам скрипт потом отказался их обрабатывать'")

    parser.add_argument("--check-plan", dest="check_plan", action="store_true", default=True,
                         help="проверять план/факт, если роль plan_value есть (по умолчанию включено)")
    parser.add_argument("--no-check-plan", dest="check_plan", action="store_false",
                         help="отключить проверку план/факт полностью")
    parser.add_argument("--periods-back", type=int, default=2,
                         help="сколько последних календарных месяцев отчитывать ОТДЕЛЬНЫМИ брифами "
                              "(по умолчанию 2 - текущий и предыдущий)")
    parser.add_argument("--recent-months", type=int, default=3)
    parser.add_argument("--deviation-threshold", type=float, default=0.1)
    parser.add_argument("--max-sane-deviation", type=float, default=5.0)
    parser.add_argument("--top-plan-deviations", type=int, default=20)
    parser.add_argument("--top-anomalies", type=int, default=10)

    parser.add_argument("--embed-model", default="/home/datalab/nfs/embed/bge-m3-local")
    parser.add_argument("--chronos-model", default="/home/datalab/nfs/chronos/autogluon_chronos-2")
    parser.add_argument("--context-length", type=int, default=6)
    parser.add_argument("--check-last-n", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=200,
                         help="макс. число показателей в одном запросе к Chronos (по умолчанию 200)")

    parser.add_argument("--api-base", default=None)
    parser.add_argument("--api-key", default=None)
    parser.add_argument("--model-name", default="default")
    parser.add_argument("--sep", default=None)

    parser.add_argument("--email", default=None,
                         help="email получателя - если указан, готовый бриф отправится на эту почту")
    parser.add_argument("--smtp-host", default=None)
    parser.add_argument("--smtp-port", type=int, default=587)
    parser.add_argument("--smtp-user", default=None)
    parser.add_argument("--smtp-password", default=None,
                         help="лучше передавать через переменную окружения SMTP_PASSWORD")
    parser.add_argument("--smtp-from", default=None)
    parser.add_argument("--no-smtp-tls", dest="smtp_tls", action="store_false", default=True)

    args = parser.parse_args()

    if args.min_periods_for_stats is None:
        # Согласуем порог с тем, что РЕАЛЬНО требует find_chronos_anomalies.py:
        # ему нужно хотя бы (min_history + 1) периодов, а min_history там по
        # умолчанию рассчитан на context_length. Без этого auto может решить,
        # что данных достаточно для Chronos, а сам скрипт откажется их обрабатывать.
        args.min_periods_for_stats = args.context_length + args.check_last_n
        print(f"--min-periods-for-stats не задан, вычислен автоматически: "
              f"{args.min_periods_for_stats} (context-length {args.context_length} + "
              f"check-last-n {args.check_last_n})", file=sys.stderr)

    source_name = sanitize_name(os.path.splitext(os.path.basename(args.input))[0])
    output_dir = os.path.join(args.work_dir, source_name)
    os.makedirs(output_dir, exist_ok=True)
    print(f"Источник: '{args.input}' -> имя для файлов: '{source_name}' -> папка: '{output_dir}'",
          file=sys.stderr)

    def out(suffix):
        return os.path.join(output_dir, f"{source_name}_{suffix}")

    column_roles_path = args.column_roles or out("column_roles.csv")
    links_path = out("links.csv")
    anomalies_path = out("anomalies.csv")
    plan_deviations_path = out("plan_deviations.csv")
    prompt_path = out("prompt_for_chat.txt")
    brief_path = out("brief.md")
    profile_prompt_path = out("prompt_profile.txt")
    response_profile_path = out("response_profile.txt")
    response_brief_path = out("response_brief.txt")

    py = sys.executable

    # ── Роли колонок ──
    if not os.path.exists(column_roles_path):
        if args.api_base:
            cmd = [py, "profile_columns.py", "--input", args.input, "--output", column_roles_path,
                   "--api-base", args.api_base, "--model-name", args.model_name]
            if args.api_key:
                cmd += ["--api-key", args.api_key]
            if args.sep:
                cmd += ["--sep", args.sep]
            run_step(f"Шаг 0: определение ролей колонок для '{source_name}' (через API)", cmd)
        else:
            print(f"Файл ролей колонок '{column_roles_path}' ещё не создан для источника '{source_name}'.\n\n"
                  f"Выполните разово (через чат LLM):\n"
                  f"  python profile_columns.py --input {args.input} --save-prompt {profile_prompt_path} --dry-run\n"
                  f"  (скопируйте промпт в чат LLM, ответ сохраните в {response_profile_path})\n"
                  f"  python profile_columns.py --input {args.input} --response-file {response_profile_path} "
                  f"--output {column_roles_path}\n\n"
                  f"Либо укажите --api-base. После этого запустите run_pipeline.py ещё раз.", file=sys.stderr)
            sys.exit(1)

    roles = load_column_roles(column_roles_path)
    print(f"Загружены роли колонок: {roles}", file=sys.stderr)

    required = ["metric_name", "date", "fact_value"]
    missing_roles = [r for r in required if r not in roles]
    if missing_roles:
        print(f"Ошибка: в '{column_roles_path}' не хватает ролей: {missing_roles}.", file=sys.stderr)
        sys.exit(1)

    metric_col = roles["metric_name"][0]
    date_col = roles["date"][0]
    value_col = roles["fact_value"][0]
    # группировка - МОЖЕТ быть несколько колонок сразу (продукт + юнит + трайб и т.п.),
    # их комбинация образует уникальный ряд для анализа
    group_cols = roles.get("unit", []) + roles.get("category", [])
    group_cols_arg = ",".join(group_cols) if group_cols else None
    plan_col = roles.get("plan_value", [None])[0]

    # ── Связи между показателями ──
    cmd = [py, "find_metric_links.py", "--input", args.input, "--column", metric_col,
           "--output", links_path, "--model", args.embed_model]
    if group_cols_arg:
        cmd += ["--group-columns", group_cols_arg]
    if args.sep:
        cmd += ["--sep", args.sep]
    run_step(f"Шаг 1: поиск связей между показателями для '{source_name}'", cmd)

    # ── Определяем статистический метод (auto - кодом, не LLM) ──
    method = args.anomaly_method
    if method == "auto":
        method, median_periods = recommend_stat_method(
            args.input, args.sep, group_cols, metric_col, date_col, args.min_periods_for_stats
        )
        print(f"Автоопределение статистического метода: медиана периодов на показатель = "
              f"{median_periods} -> выбран метод '{method}'", file=sys.stderr)

    ran_stats = method != "none"
    ran_plan = False

    if ran_stats:
        if method == "chronos":
            script = "find_chronos_anomalies.py"
            # min-history меньше порога, при котором auto вообще включает Chronos,
            # на величину check-last-n - иначе показатель, который auto посчитал
            # "достаточным", сам find_chronos_anomalies.py может отбросить
            chronos_min_history = max(1, args.min_periods_for_stats - args.check_last_n)
            extra = ["--model", args.chronos_model,
                     "--context-length", str(args.context_length),
                     "--check-last-n", str(args.check_last_n),
                     "--min-history", str(chronos_min_history),
                     "--batch-size", str(args.batch_size),
                     "--periods-back", str(args.periods_back)]
        else:
            script = "find_var_anomalies.py"
            extra = ["--periods-back", str(args.periods_back)]

        cmd = [py, script, "--input", args.input,
               "--metric-column", metric_col, "--date-column", date_col, "--value-column", value_col,
               "--links-file", links_path, "--output", anomalies_path] + extra
        if group_cols_arg:
            cmd += ["--unit-columns", group_cols_arg]
        if args.sep:
            cmd += ["--sep", args.sep]
        run_step(f"Шаг 2а: статистический поиск аномалий для '{source_name}' ({script})", cmd)
    else:
        print("Статистический метод отключён (недостаточно периодов или выбрано --anomaly-method none).",
              file=sys.stderr)

    # ── План/факт - ВСЕГДА дополнительно, если роль есть и не отключено явно ──
    if args.check_plan and plan_col:
        cmd = [py, "find_plan_deviations.py", "--input", args.input,
               "--metric-column", metric_col, "--date-column", date_col,
               "--value-column", value_col, "--plan-column", plan_col,
               "--periods-back", str(args.periods_back),
               "--recent-months", str(args.recent_months),
               "--deviation-threshold", str(args.deviation_threshold),
               "--max-sane-deviation", str(args.max_sane_deviation),
               "--output", plan_deviations_path]
        if group_cols_arg:
            cmd += ["--unit-columns", group_cols_arg]
        if args.sep:
            cmd += ["--sep", args.sep]
        run_step(f"Шаг 2б: проверка план/факт для '{source_name}' (дополнительно к статистике)", cmd)
        ran_plan = True
    elif args.check_plan and not plan_col:
        print("Роли 'plan_value' нет в column_roles.csv — проверка план/факт пропущена "
              "(это не ошибка, просто плана в данных не найдено).", file=sys.stderr)

    if not ran_stats and not ran_plan:
        print("Ошибка: не сработал ни статистический метод, ни план/факт - "
              "нет первичных фактов для брифа. Проверьте объём данных и наличие плана.", file=sys.stderr)
        sys.exit(1)

    email_args = []
    if args.email:
        email_args += ["--email", args.email]
        if args.smtp_host:
            email_args += ["--smtp-host", args.smtp_host, "--smtp-port", str(args.smtp_port)]
        if args.smtp_user:
            email_args += ["--smtp-user", args.smtp_user]
        if args.smtp_password:
            email_args += ["--smtp-password", args.smtp_password]
        if args.smtp_from:
            email_args += ["--smtp-from", args.smtp_from]
        if not args.smtp_tls:
            email_args += ["--no-smtp-tls"]

    def rank_label(rank):
        return {0: "current", 1: "previous"}.get(rank, f"rank{rank}")

    manual_instructions = []
    generated_briefs = []

    # ── Бриф: отдельный файл на каждый период (текущий, предыдущий, ...) ──
    for rank in range(args.periods_back):
        label = rank_label(rank)
        rank_brief_path = out(f"brief_{label}.md")
        rank_prompt_path = out(f"prompt_for_chat_{label}.txt")
        rank_response_path = out(f"response_brief_{label}.txt")

        brief_facts_arg = ["--period-rank", str(rank)]
        if ran_stats:
            brief_facts_arg += ["--anomalies", anomalies_path, "--top-anomalies", str(args.top_anomalies)]
        if ran_plan:
            brief_facts_arg += ["--plan-deviations", plan_deviations_path,
                                 "--top-plan-deviations", str(args.top_plan_deviations)]

        if args.api_base:
            cmd = [py, "generate_brief.py"] + brief_facts_arg + ["--links", links_path,
                   "--output", rank_brief_path, "--api-base", args.api_base,
                   "--model-name", args.model_name] + email_args
            if args.api_key:
                cmd += ["--api-key", args.api_key]
            run_step(f"Шаг 3 ({label}): генерация брифа для '{source_name}' напрямую через API", cmd)
            generated_briefs.append(rank_brief_path)
        else:
            cmd = [py, "generate_brief.py"] + brief_facts_arg + ["--links", links_path,
                   "--output", rank_brief_path, "--dry-run", "--save-prompt", rank_prompt_path]
            run_step(f"Шаг 3 ({label}): сборка промпта для брифа для '{source_name}'", cmd)
            manual_instructions.append(
                f"  Период '{label}':\n"
                f"    1. Откройте '{rank_prompt_path}', скопируйте в чат вашей LLM\n"
                f"    2. Ответ модели сохраните в {rank_response_path}\n"
                f"    3. Запустите:\n"
                f"       python generate_brief.py {' '.join(brief_facts_arg)} --links {links_path} "
                f"--output {rank_brief_path} --response-file {rank_response_path} {' '.join(email_args)}\n"
            )

    if args.api_base:
        print(f"\n{'='*70}\nГОТОВО — весь пайплайн для '{source_name}' выполнен автоматически.\n{'='*70}",
              file=sys.stderr)
        print(f"Папка результатов: {output_dir}", file=sys.stderr)
        for p in generated_briefs:
            print(f"Готовый бриф: {p}", file=sys.stderr)
    else:
        print(f"\n{'='*70}\nАвтоматическая часть для '{source_name}' завершена ({args.periods_back} "
              f"период(ов)).\n{'='*70}", file=sys.stderr)
        print(f"Папка результатов: {output_dir}", file=sys.stderr)
        print(f"\nОсталось руками, отдельно для каждого периода:\n" + "\n".join(manual_instructions),
              file=sys.stderr)


if __name__ == "__main__":
    main()

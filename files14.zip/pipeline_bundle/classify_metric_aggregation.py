"""
Определяет для КАЖДОГО показателя (значения в колонке metric_name), как его
правильно агрегировать при схлопывании нескольких строк в один период:
  - "sum"  — суммировать (для потоковых величин: выручка, число заявок)
  - "mean" — усреднять (для отношений: конверсия, средний чек, доля, %)
  - "last" — брать последнее значение (для "снимков на момент": остаток на
             счету, статус, или план, если он константой продублирован по строкам)

Зачем это нужно: при дневных/транзакционных данных, схлопнутых в месяц,
слепое суммирование ломает показатели-отношения (сумма 30 дневных % конверсии —
бессмысленное число) и показатели-константы (план, продублированный на
каждый день, при суммировании "раздувается" в N раз).

ВАЖНО: скрипт сам определяет гранулярность данных (дневная/недельная/месячная)
и передаёт это LLM как контекст — если данные УЖЕ месячные, вопрос агрегации
неактуален (агрегировать почти нечего), LLM это увидит и учтёт.

Запуск, шаг 1 — собрать профиль показателей и промпт:
    python classify_metric_aggregation.py --input facts.csv --metric-column pokaz_name \\
        --date-column date_ --value-column fact --save-prompt prompt_agg.txt --dry-run

Запуск, шаг 2 — после того как вставили ответ LLM в файл:
    python classify_metric_aggregation.py --input facts.csv --metric-column pokaz_name \\
        --date-column date_ --value-column fact --response-file response_agg.txt --output metric_aggregation.csv

Либо сразу через API (см. --api-base в других скриптах пайплайна) — аргументы те же.

Параметры:
    --input          CSV/Excel с фактами
    --sheet          лист Excel (не используется для CSV)
    --metric-column  колонка с названием показателя
    --date-column    колонка с датой/периодом
    --value-column   колонка со значением
    --sample-size    сколько примеров значений показывать LLM на показатель (по умолчанию 5)
    --save-prompt / --dry-run / --response-file / --api-base / --api-key / --model-name —
        тот же ручной/API режим, что и в остальных скриптах пайплайна
    --output         путь к результирующему CSV (metric_name;aggregation_method;reasoning)
    --sep            разделитель CSV (по умолчанию автоопределение)
"""

import argparse
import json
import os
import re
import sys

import pandas as pd


def _read_csv_robust(path: str, sep: str) -> pd.DataFrame:
    """Читает CSV устойчиво к двум частым проблемам реальных выгрузок:
    - отдельные строки с "битыми" символами (не в той кодировке) -> заменяются
      на символ-заглушку вместо падения всего чтения;
    - отдельные строки с неверным числом полей (лишние/недостающие разделители)
      -> пропускаются с предупреждением, а не обрывают чтение всего файла.
    """
    skipped = []

    def _on_bad_line(bad_line):
        skipped.append(bad_line)
        return None  # пропустить эту строку

    try:
        df = pd.read_csv(path, sep=sep, encoding="utf-8-sig", on_bad_lines=_on_bad_line, engine="python")
    except UnicodeDecodeError:
        with open(path, "rb") as f:
            raw = f.read()
        text = raw.decode("utf-8", errors="replace")
        from io import StringIO
        skipped.clear()
        df = pd.read_csv(StringIO(text), sep=sep, on_bad_lines=_on_bad_line, engine="python")
        print("Предупреждение: файл не был в чистом UTF-8, часть символов могла замениться на '?'.",
              file=sys.stderr)

    if skipped:
        print(f"Пропущено ошибочных строк CSV (неверное число полей): {len(skipped)}", file=sys.stderr)

    return df


def read_input_auto(path: str, sep, sheet=0):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xls"):
        return pd.read_excel(path, sheet_name=sheet)
    if sep:
        return _read_csv_robust(path, sep)
    for candidate in (";", ","):
        df = _read_csv_robust(path, candidate)
        if df.shape[1] > 1:
            return df
    return df


def read_text_auto_encoding(path: str) -> str:
    for encoding in ("utf-8-sig", "utf-8", "cp1251", "latin-1"):
        try:
            with open(path, "r", encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Не удалось прочитать '{path}' ни в одной из известных кодировок.")


def detect_granularity(dates: pd.Series) -> str:
    """Смотрит на медианный шаг между соседними датами конкретного показателя,
    чтобы понять: это дневные данные, недельные, месячные или что-то ещё."""
    parsed = pd.to_datetime(dates, errors="coerce").dropna().sort_values().unique()
    if len(parsed) < 2:
        return "неизвестно (мало точек)"
    diffs = pd.Series(parsed).diff().dropna().dt.days
    median_gap = diffs.median()
    if median_gap <= 1.5:
        return "дневная"
    if median_gap <= 8:
        return "недельная"
    if median_gap <= 35:
        return "месячная"
    return f"крупнее месячной (медианный шаг {median_gap:.0f} дн.)"


def build_metric_profile(df: pd.DataFrame, metric_col: str, date_col: str, value_col: str,
                          plan_col: str, sample_size: int):
    profile = []
    for metric, sub in df.groupby(metric_col):
        granularity = detect_granularity(sub[date_col])
        fact_samples = sub[value_col].dropna().drop_duplicates().head(sample_size).tolist()
        entry = {
            "metric_name": str(metric),
            "granularity": granularity,
            "rows_total": len(sub),
            "fact_sample_values": [str(s) for s in fact_samples],
        }
        if plan_col and plan_col in sub.columns:
            plan_samples = sub[plan_col].dropna().drop_duplicates().head(sample_size).tolist()
            entry["plan_sample_values"] = [str(s) for s in plan_samples]
            # подсказка модели: если план не меняется от строки к строке - это почти
            # наверняка константа, продублированная, а не то, что нужно суммировать
            entry["plan_is_constant_within_metric"] = sub[plan_col].nunique(dropna=True) <= 1
        profile.append(entry)
    return profile


PROMPT_TEMPLATE = """Ты помощник по анализу данных. Ниже — список показателей с их гранулярностью
(как часто встречаются даты в данных) и примерами значений. Определи, КАК правильно
агрегировать ФАКТ и (если есть) ПЛАН каждого показателя при схлопывании нескольких строк
в один более крупный период (например, дневных строк в один месяц). Факт и план для одного
и того же показателя МОГУТ требовать РАЗНЫХ способов агрегации — оценивай их отдельно.

Возможные способы:
- "sum"  — суммировать. Для ПОТОКОВЫХ величин: выручка, число заявок, число транзакций,
  количество чего-либо за период. Правильно, если смысл сохраняется при сложении.
- "mean" — усреднять. Для ОТНОШЕНИЙ и долей: проценты, конверсия, средний чек, доля,
  rate, ratio. Суммировать их НЕЛЬЗЯ.
- "last" — брать последнее (или любое одно) значение, не складывать и не усреднять.
  Для "снимков на момент" (остаток, статус) — а также для ПЛАНА, если он константой
  повторяется в каждой строке (одно и то же число на каждый день) — такой план
  ОБЯЗАТЕЛЬНО должен агрегироваться как "last", суммирование его "раздует" в N раз.

ВАЖНАЯ ПОДСКАЗКА: в профиле есть поле "plan_is_constant_within_metric" — если True,
это значит, что все встреченные значения плана для этого показателя одинаковы (то есть
план физически продублирован на каждую строку) — почти наверняка нужен "last", не "sum".

КАК ИСПОЛЬЗОВАТЬ ГРАНУЛЯРНОСТЬ: если гранулярность уже "месячная" — вопрос агрегации
почти неактуален (там и так почти одна строка на период). Если "дневная" — критично важно.

ПРАВИЛА:
1. Используй ТОЛЬКО названия показателей из списка ниже, ничего не придумывай.
2. Если у показателя нет поля plan_sample_values — не указывай plan_aggregation вообще.
3. Если не уверен — выбирай "sum" для факта как безопасный дефолт, но явно указывай
   confidence "low" и поясняй сомнение в reasoning.
4. Верни ТОЛЬКО валидный JSON как обычный текстовый (plain text) ответ:
   - без markdown-разметки и без блоков ```;
   - без пояснений, комментариев или заголовков до или после JSON;
   - первый символ твоего ответа должен быть "{{", последний — "}}".

Формат ответа:
{{
  "metrics": [
    {{"metric_name": "название", "fact_aggregation": "sum|mean|last",
      "plan_aggregation": "sum|mean|last или null, если плана нет",
      "confidence": "high|medium|low", "reasoning": "почему"}}
  ]
}}

Показатели:
{profile_json}
"""


def build_prompt(profile: list) -> str:
    return PROMPT_TEMPLATE.format(profile_json=json.dumps(profile, ensure_ascii=False, indent=2))


def parse_llm_response(raw_response: str, valid_metrics: set):
    cleaned = re.sub(r"^```(json)?|```$", "", raw_response.strip(), flags=re.MULTILINE).strip()
    cleaned = cleaned.lstrip("\ufeff")
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise ValueError(f"LLM вернула невалидный JSON: {e}\nОтвет был:\n{raw_response}")

    valid_methods = ("sum", "mean", "last")
    valid, rejected = [], []
    for item in data.get("metrics", []):
        if item.get("metric_name") not in valid_metrics:
            rejected.append(item)
            continue
        if item.get("fact_aggregation") not in valid_methods:
            rejected.append(item)
            continue
        if item.get("plan_aggregation") is not None and item.get("plan_aggregation") not in valid_methods:
            rejected.append(item)
            continue
        valid.append(item)
    return valid, rejected


def call_llm(prompt: str, api_base: str, api_key: str = None, model_name: str = "default", timeout: int = 120) -> str:
    import requests
    url = api_base.rstrip("/")
    if not url.endswith("/chat/completions"):
        url += "/chat/completions"
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    resp = requests.post(url, headers=headers, json={
        "model": model_name, "messages": [{"role": "user", "content": prompt}], "temperature": 0.2,
    }, timeout=timeout)
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"]


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True)
    parser.add_argument("--sheet", default=0)
    parser.add_argument("--metric-column", default="metric_name")
    parser.add_argument("--date-column", default="d_date")
    parser.add_argument("--value-column", default="fact_value")
    parser.add_argument("--plan-column", default=None,
                         help="колонка с плановым значением, если есть - будет классифицирована отдельно от факта")
    parser.add_argument("--sample-size", type=int, default=5)
    parser.add_argument("--save-prompt", default=None)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--response-file", default=None)
    parser.add_argument("--api-base", default=None)
    parser.add_argument("--api-key", default=None)
    parser.add_argument("--model-name", default="default")
    parser.add_argument("--output", default=None)
    parser.add_argument("--sep", default=None)
    args = parser.parse_args()

    df = read_input_auto(args.input, args.sep, args.sheet)
    for col in (args.metric_column, args.date_column, args.value_column):
        if col not in df.columns:
            print(f"Ошибка: колонки '{col}' нет в файле. Доступные: {list(df.columns)}", file=sys.stderr)
            sys.exit(1)
    if args.plan_column and args.plan_column not in df.columns:
        print(f"Ошибка: колонки '{args.plan_column}' нет в файле.", file=sys.stderr)
        sys.exit(1)

    profile = build_metric_profile(df, args.metric_column, args.date_column, args.value_column,
                                    args.plan_column, args.sample_size)
    print(f"Показателей для классификации: {len(profile)}", file=sys.stderr)
    for p in profile:
        print(f"  {p['metric_name']}: гранулярность={p['granularity']}, "
              f"примеры={p['sample_values'][:3]}", file=sys.stderr)

    prompt = build_prompt(profile)

    if args.save_prompt:
        with open(args.save_prompt, "w", encoding="utf-8") as f:
            f.write(prompt)
        print(f"\nПромпт сохранён в '{args.save_prompt}' — скопируйте в чат вашей LLM.", file=sys.stderr)

    if args.dry_run:
        print("\n──── ПРОМПТ (dry-run) ────\n", file=sys.stderr)
        print(prompt)
        return

    if args.response_file:
        raw_response = read_text_auto_encoding(args.response_file)
    elif args.api_base:
        print(f"Вызываю LLM напрямую через {args.api_base}...", file=sys.stderr)
        raw_response = call_llm(prompt, api_base=args.api_base, api_key=args.api_key, model_name=args.model_name)
    else:
        print("Ошибка: укажите --response-file, --api-base или --dry-run.", file=sys.stderr)
        sys.exit(1)

    valid_metrics = {p["metric_name"] for p in profile}
    valid, rejected = parse_llm_response(raw_response, valid_metrics)
    if rejected:
        print(f"ВНИМАНИЕ: отклонено {len(rejected)} записей (несуществующий показатель "
              f"или неверный aggregation_method): {rejected}", file=sys.stderr)

    result_df = pd.DataFrame(valid)
    print("\n──── Способы агрегации ────", file=sys.stderr)
    for _, row in result_df.iterrows():
        plan_part = f", план: {row.get('plan_aggregation') or '—'}"
        print(f"  {row['metric_name']:20s} -> факт: {row['fact_aggregation']:5s}{plan_part} "
              f"({row['confidence']}): {row['reasoning']}", file=sys.stderr)

    if args.output:
        result_df.to_csv(args.output, sep=";", index=False, encoding="utf-8-sig")
        print(f"\nСохранено в '{args.output}'.", file=sys.stderr)


if __name__ == "__main__":
    main()

"""
Ищет КРУПНЫЕ ОТКЛОНЕНИЯ ФАКТА ОТ ПЛАНА за последние N периодов (по умолчанию 3).

В отличие от VAR/Chronos, этому методу НЕ нужна длинная история — он просто
сравнивает факт с планом на каждую из последних дат. Подходит именно для
случаев с малым числом периодов (месячные итоги, квартальные срезы и т.п.),
где статистические модели ненадёжны из-за нехватки данных.

Ожидаемый формат входных данных (длинный формат):
    unit_name (опционально); metric_name; d_date; fact_value; plan_value

Запуск:
    python find_plan_deviations.py --input facts.csv \\
        --metric-column pokaz_name --date-column date_ \\
        --value-column fact --plan-column plan \\
        --output plan_deviations.csv

Параметры:
    --input              CSV/Excel с фактами
    --sheet              лист Excel (не используется для CSV)
    --unit-column        (опционально) колонка юнита
    --metric-column      колонка с названием показателя
    --date-column        колонка с датой/периодом
    --value-column       колонка с фактическим значением
    --plan-column        колонка с плановым значением
    --recent-months      сколько последних периодов проверять (по умолчанию 3)
    --deviation-threshold относительное отклонение, начиная с которого считается
                          "крупным" (по умолчанию 0.1 = 10%)
    --output             путь к результирующему CSV
    --sep                разделитель CSV (по умолчанию автоопределение)
"""

import argparse
import os
import sys

import pandas as pd


def _read_csv_robust(path: str, sep: str) -> pd.DataFrame:
    """Читает CSV устойчиво к двум частым проблемам реальных выгрузок:
    - отдельные строки с "битыми" символами (не в той кодировке) -> заменяются
      на символ-заглушку вместо падения всего чтения;
    - отдельные строки с неверным числом полей (лишние/недостающие разделители)
      -> пропускаются с предупреждением, а не обрывают чтение всего файла.
    """
    skipped = []

    def _on_bad_line(bad_line):
        skipped.append(bad_line)
        return None  # пропустить эту строку

    try:
        df = pd.read_csv(path, sep=sep, encoding="utf-8-sig", on_bad_lines=_on_bad_line, engine="python")
    except UnicodeDecodeError:
        with open(path, "rb") as f:
            raw = f.read()
        text = raw.decode("utf-8", errors="replace")
        from io import StringIO
        skipped.clear()
        df = pd.read_csv(StringIO(text), sep=sep, on_bad_lines=_on_bad_line, engine="python")
        print("Предупреждение: файл не был в чистом UTF-8, часть символов могла замениться на '?'.",
              file=sys.stderr)

    if skipped:
        print(f"Пропущено ошибочных строк CSV (неверное число полей): {len(skipped)}", file=sys.stderr)

    return df


def read_input_auto(path: str, sep, sheet=0):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xls"):
        return pd.read_excel(path, sheet_name=sheet)
    if sep:
        return _read_csv_robust(path, sep)
    for candidate in (";", ","):
        df = _read_csv_robust(path, candidate)
        if df.shape[1] > 1:
            return df
    return df


def compute_full_streak(classified_rows: list) -> int:
    """Считает, сколько ПОСЛЕДНИХ ПОДРЯД периодов (по всей доступной истории,
    не только по окну --recent-months) показатель был в состоянии крупного
    отклонения В ОДНОМ И ТОМ ЖЕ направлении. Если последний период не является
    крупным отклонением — возвращает 0.

    classified_rows: список dict в хронологическом порядке (от старых к новым),
    каждый с ключами 'is_large_deviation' и 'deviation_pct'.
    """
    if not classified_rows:
        return 0
    last = classified_rows[-1]
    if not last["is_large_deviation"]:
        return 0

    last_sign = 1 if last["deviation_pct"] > 0 else -1
    streak = 0
    for row in reversed(classified_rows):
        if not row["is_large_deviation"]:
            break
        sign = 1 if row["deviation_pct"] > 0 else -1
        if sign != last_sign:
            break
        streak += 1
    return streak


def classify_deviation(fact, plan, threshold, max_sane_deviation):
    """Возвращает (deviation_abs, deviation_pct, status, is_large_deviation, is_suspicious).

    max_sane_deviation — потолок правдоподобия (например, 5.0 = 500%). Отклонения
    выше этого порога почти всегда означают не реальную бизнес-аномалию, а ошибку
    в данных (единицы измерения перепутаны, дублирование строк и т.п.) — такие
    случаи помечаются "подозрительное значение" и НЕ попадают в крупные отклонения
    для брифа, но остаются видны в файле для проверки качества данных.
    """
    if plan is None or pd.isna(plan) or plan == 0:
        return None, None, "нет плана", False, False
    if fact is None or pd.isna(fact):
        return None, None, "нет данных", False, False

    deviation_abs = fact - plan
    deviation_pct = deviation_abs / abs(plan)

    is_suspicious = abs(deviation_pct) > max_sane_deviation
    if is_suspicious:
        return round(deviation_abs, 4), round(deviation_pct, 4), \
            "подозрительное значение — проверьте данные", False, True

    is_large = abs(deviation_pct) >= threshold
    if not is_large:
        status = "в пределах нормы"
    elif deviation_pct > 0:
        status = "крупное превышение плана"
    else:
        status = "крупный срыв плана"

    return round(deviation_abs, 4), round(deviation_pct, 4), status, is_large, False


def load_aggregation_map(path: str) -> tuple:
    """Читает результат classify_metric_aggregation.py. Возвращает (fact_map, plan_map) —
    способ агрегации для факта и для плана МОГУТ ОТЛИЧАТЬСЯ для одного и того же
    показателя (например, факт суммируется, а план — константа, берётся 'last')."""
    if not path:
        return {}, {}
    agg_df = pd.read_csv(path, sep=";", encoding="utf-8-sig")
    fact_map = dict(zip(agg_df["metric_name"], agg_df["fact_aggregation"]))
    plan_map = {}
    if "plan_aggregation" in agg_df.columns:
        plan_map = {
            m: v for m, v in zip(agg_df["metric_name"], agg_df["plan_aggregation"])
            if pd.notna(v)
        }
    return fact_map, plan_map


def aggregate_series(sub: pd.DataFrame, fact_method: str, plan_method: str) -> pd.DataFrame:
    """Агрегирует факт и план по ИХ СОБСТВЕННЫМ способам (могут отличаться друг от друга)."""
    def _agg(method):
        return {"mean": "mean", "last": "last"}.get(method, "sum")

    fact_agg = sub.groupby("d_date")["fact_value"].agg(_agg(fact_method))
    plan_agg = sub.groupby("d_date")["plan_value"].agg(_agg(plan_method))
    return pd.DataFrame({"fact_value": fact_agg, "plan_value": plan_agg})


def normalize_month(series: pd.Series) -> pd.Series:
    """Приводит даты к чистому виду 'YYYY-MM', даже если исходно это были
    полные datetime-значения вроде '2026-09-30T00:00:00' (частая история,
    когда столбец с датой в источнике хранится как настоящий datetime,
    а не текстовый период). Если значения не похожи на реальные даты
    (например, синтетические метки вроде 'P00') — оставляет как есть.
    """
    parsed = pd.to_datetime(series, errors="coerce")
    if parsed.notna().mean() > 0.8:  # похоже, что это реальные даты
        return parsed.dt.strftime("%Y-%m")
    return series.astype(str).str.strip()


def detect_target_periods(df: pd.DataFrame, count: int = 2) -> list:
    """Последние `count` календарных месяцев, встречающихся в данных, НО НЕ ПОЗЖЕ
    текущего месяца (прогнозы/план на будущее не считаются "текущим" периодом).
    Возвращает список от самого свежего к более старому, например ['2026-07', '2026-06'].
    """
    import datetime
    dates = df["d_date"].astype(str).str.strip()
    current_month = datetime.date.today().strftime("%Y-%m")
    valid = sorted((d for d in dates.unique() if d <= current_month), reverse=True)
    if valid:
        return valid[:count]
    return [dates.max()]  # запасной вариант, если вообще все даты в будущем


def format_period_human(period: str) -> str:
    """'2026-07' -> 'Июль 26' - человекочитаемый вид периода для заголовка брифа."""
    months = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
              "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]
    try:
        year, month = period.split("-")[:2]
        return f"{months[int(month) - 1]} {int(year) % 100:02d}"
    except (ValueError, IndexError):
        return period


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True)
    parser.add_argument("--sheet", default=0)
    parser.add_argument("--unit-columns", default=None,
                         help="одна или несколько колонок группировки через запятую (например: продукт,юнит,трайб) - их комбинация образует ряд для анализа")
    parser.add_argument("--metric-column", default="metric_name")
    parser.add_argument("--date-column", default="d_date")
    parser.add_argument("--value-column", default="fact_value")
    parser.add_argument("--plan-column", required=True, help="колонка с плановым значением")
    parser.add_argument("--aggregation-file", default=None,
                         help="CSV из classify_metric_aggregation.py - способ агрегации (sum/mean/last) "
                              "для каждого показателя. Без этого параметра всё суммируется, как раньше.")
    parser.add_argument("--periods-back", type=int, default=2,
                         help="сколько последних календарных месяцев считать 'текущими' для отчёта "
                              "(по умолчанию 2 — текущий и предыдущий), каждый оценивается независимо")
    parser.add_argument("--recent-months", type=int, default=3,
                         help="сколько последних периодов сохранить в CSV для ручной проверки "
                              "(не влияет на выбор фактов для брифа - это делает --periods-back)")
    parser.add_argument("--deviation-threshold", type=float, default=0.1,
                         help="относительное отклонение, начиная с которого оно 'крупное' (по умолчанию 0.1)")
    parser.add_argument("--max-sane-deviation", type=float, default=5.0,
                         help="потолок правдоподобия отклонения (по умолчанию 5.0 = 500%%). "
                              "Выше этого — считается ошибкой в данных, не реальной аномалией, "
                              "и не попадает в 'крупные отклонения' для брифа")
    parser.add_argument("--output", required=True)
    parser.add_argument("--sep", default=None)
    args = parser.parse_args()

    df = read_input_auto(args.input, args.sep, args.sheet)

    rename_map = {
        args.metric_column: "metric_name",
        args.date_column: "d_date",
        args.value_column: "fact_value",
        args.plan_column: "plan_value",
    }
    for user_col in rename_map:
        if user_col not in df.columns:
            print(f"Ошибка: колонки '{user_col}' нет в файле. Доступные: {list(df.columns)}", file=sys.stderr)
            sys.exit(1)
    df = df.rename(columns=rename_map)

    if args.unit_columns:
        unit_col_list = [c.strip() for c in args.unit_columns.split(",") if c.strip()]
        missing = [c for c in unit_col_list if c not in df.columns]
        if missing:
            print(f"Ошибка: колонок группировки нет в файле: {missing}.", file=sys.stderr)
            sys.exit(1)
        # объединяем НЕСКОЛЬКО колонок группировки (продукт+юнит+трайб и т.п.) в один
        # составной ключ - каждая уникальная комбинация становится отдельным рядом
        df["unit_name"] = df[unit_col_list].astype(str).agg(" | ".join, axis=1)
    else:
        df["unit_name"] = "_all_"

    df["metric_name"] = df["metric_name"].astype(str).str.strip()
    df["unit_name"] = df["unit_name"].astype(str).str.strip()
    df["d_date"] = normalize_month(df["d_date"].astype(str).str.strip())
    df["fact_value"] = pd.to_numeric(df["fact_value"], errors="coerce")
    df["plan_value"] = pd.to_numeric(df["plan_value"], errors="coerce")

    fact_agg_map, plan_agg_map = load_aggregation_map(args.aggregation_file)
    if fact_agg_map:
        print(f"Загружены индивидуальные способы агрегации для {len(fact_agg_map)} показателей "
              f"(остальные — сумма по умолчанию).", file=sys.stderr)

    target_periods = detect_target_periods(df, args.periods_back)
    period_rank = {p: i for i, p in enumerate(target_periods)}  # 0 = самый свежий, 1 = предыдущий, ...
    print(f"Целевые периоды отчёта: {target_periods}", file=sys.stderr)

    results = []
    unique_series = df[["unit_name", "metric_name"]].drop_duplicates().values.tolist()
    print(f"Всего рядов для проверки: {len(unique_series)}", file=sys.stderr)

    skipped_no_target = 0
    for unit, metric in unique_series:
        sub = df[(df["unit_name"] == unit) & (df["metric_name"] == metric)]
        fact_method = fact_agg_map.get(metric, "sum")
        plan_method = plan_agg_map.get(metric, "sum")
        sub = aggregate_series(sub, fact_method, plan_method).sort_index()
        label = f"{unit}:{metric}" if unit != "_all_" else metric

        # классифицируем историю ТОЛЬКО ДО самого свежего целевого периода включительно
        full_classified = []
        for date, row in sub.iterrows():
            if date > target_periods[0]:
                continue
            dev_abs, dev_pct, status, is_large, is_suspicious = classify_deviation(
                row["fact_value"], row["plan_value"], args.deviation_threshold, args.max_sane_deviation
            )
            full_classified.append({
                "date": date, "fact_value": row["fact_value"], "plan_value": row["plan_value"],
                "deviation_abs": dev_abs, "deviation_pct": dev_pct,
                "status": status, "is_large_deviation": is_large, "is_suspicious": is_suspicious,
            })

        if not full_classified:
            skipped_no_target += 1
            continue

        by_date = {item["date"]: idx for idx, item in enumerate(full_classified)}
        found_any_target = False
        target_info_by_idx = {}  # idx -> (is_target, target_period, period_rank, streak, streak_longer)

        for target_period in target_periods:
            if target_period not in by_date:
                continue  # у показателя нет данных именно за этот целевой период
            found_any_target = True

            # серия (streak) считается НЕЗАВИСИМО для каждого целевого периода -
            # "сколько месяцев подряд отклонение длится, если смотреть НАЗАД от этого периода"
            idx = by_date[target_period]
            history_up_to_here = full_classified[:idx + 1]
            full_streak = compute_full_streak(history_up_to_here)
            streak_may_be_longer = full_streak == len(history_up_to_here) and full_streak > 0
            target_info_by_idx[idx] = (target_period, period_rank[target_period], full_streak, streak_may_be_longer)

        if not found_any_target:
            skipped_no_target += 1
            continue

        # один объединённый диапазон для вывода в CSV (без дублей строк на серию):
        # от самого раннего нужного окна до самого свежего целевого периода
        earliest_target_idx = min(target_info_by_idx)
        window_start = max(0, earliest_target_idx - args.recent_months + 1)
        window_end = max(target_info_by_idx)

        for idx in range(window_start, window_end + 1):
            w = full_classified[idx]
            info = target_info_by_idx.get(idx)
            results.append({
                "unit_name": unit, "metric_name": metric, "series": label, "date": w["date"],
                "fact_value": w["fact_value"], "plan_value": w["plan_value"],
                "deviation_abs": w["deviation_abs"], "deviation_pct": w["deviation_pct"],
                "status": w["status"], "is_large_deviation": w["is_large_deviation"],
                "is_suspicious": w["is_suspicious"],
                "streak_length": info[2] if info else None,
                "streak_may_be_longer": info[3] if info else None,
                "is_target_period": info is not None,
                "target_period": info[0] if info else None,
                "period_rank": info[1] if info else None,
            })

    if skipped_no_target:
        print(f"Пропущено показателей без данных ни за один из целевых периодов {target_periods}: "
              f"{skipped_no_target}", file=sys.stderr)

    if not results:
        print("Не найдено ни одной строки для проверки.", file=sys.stderr)
        sys.exit(1)

    result_df = pd.DataFrame(results)
    result_df["_abs_dev"] = result_df["deviation_pct"].abs()
    result_df = result_df.sort_values(["date", "_abs_dev"], ascending=[False, False], na_position="last")
    result_df = result_df.drop(columns=["_abs_dev"])
    result_df.to_csv(args.output, sep=";", index=False, encoding="utf-8-sig")

    n_large = int(result_df["is_large_deviation"].sum())
    n_suspicious = int(result_df["is_suspicious"].sum())
    print(f"Готово. Крупных отклонений: {n_large} из {len(result_df)} проверенных строк. "
          f"Результат: '{args.output}'.", file=sys.stderr)
    if n_suspicious:
        print(f"ВНИМАНИЕ: {n_suspicious} значений помечены как подозрительные "
              f"(отклонение больше {args.max_sane_deviation * 100:.0f}%) — скорее всего, ошибка "
              f"в данных, а не реальная бизнес-аномалия. Они НЕ попадут в бриф автоматически, "
              f"но видны в файле результата (status='подозрительное значение...') — стоит "
              f"проверить исходные данные по этим строкам.", file=sys.stderr)


if __name__ == "__main__":
    main()

"""
Ищет КРУПНЫЕ ОТКЛОНЕНИЯ ФАКТА ОТ ПЛАНА за последние N периодов (по умолчанию 3).

В отличие от VAR/Chronos, этому методу НЕ нужна длинная история — он просто
сравнивает факт с планом на каждую из последних дат. Подходит именно для
случаев с малым числом периодов (месячные итоги, квартальные срезы и т.п.),
где статистические модели ненадёжны из-за нехватки данных.

Ожидаемый формат входных данных (длинный формат):
    unit_name (опционально); metric_name; d_date; fact_value; plan_value

Запуск:
    python find_plan_deviations.py --input facts.csv \\
        --metric-column pokaz_name --date-column date_ \\
        --value-column fact --plan-column plan \\
        --output plan_deviations.csv

Параметры:
    --input              CSV/Excel с фактами
    --sheet              лист Excel (не используется для CSV)
    --unit-column        (опционально) колонка юнита
    --metric-column      колонка с названием показателя
    --date-column        колонка с датой/периодом
    --value-column       колонка с фактическим значением
    --plan-column        колонка с плановым значением
    --recent-months      сколько последних периодов проверять (по умолчанию 3)
    --deviation-threshold относительное отклонение, начиная с которого считается
                          "крупным" (по умолчанию 0.1 = 10%)
    --output             путь к результирующему CSV
    --sep                разделитель CSV (по умолчанию автоопределение)
"""

import argparse
import os
import sys

import pandas as pd


def read_input_auto(path: str, sep, sheet=0):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xls"):
        return pd.read_excel(path, sheet_name=sheet)
    if sep:
        return pd.read_csv(path, sep=sep, encoding="utf-8-sig")
    for candidate in (";", ","):
        df = pd.read_csv(path, sep=candidate, encoding="utf-8-sig")
        if df.shape[1] > 1:
            return df
    return df


def compute_full_streak(classified_rows: list) -> int:
    """Считает, сколько ПОСЛЕДНИХ ПОДРЯД периодов (по всей доступной истории,
    не только по окну --recent-months) показатель был в состоянии крупного
    отклонения В ОДНОМ И ТОМ ЖЕ направлении. Если последний период не является
    крупным отклонением — возвращает 0.

    classified_rows: список dict в хронологическом порядке (от старых к новым),
    каждый с ключами 'is_large_deviation' и 'deviation_pct'.
    """
    if not classified_rows:
        return 0
    last = classified_rows[-1]
    if not last["is_large_deviation"]:
        return 0

    last_sign = 1 if last["deviation_pct"] > 0 else -1
    streak = 0
    for row in reversed(classified_rows):
        if not row["is_large_deviation"]:
            break
        sign = 1 if row["deviation_pct"] > 0 else -1
        if sign != last_sign:
            break
        streak += 1
    return streak


def classify_deviation(fact, plan, threshold, max_sane_deviation):
    """Возвращает (deviation_abs, deviation_pct, status, is_large_deviation, is_suspicious).

    max_sane_deviation — потолок правдоподобия (например, 5.0 = 500%). Отклонения
    выше этого порога почти всегда означают не реальную бизнес-аномалию, а ошибку
    в данных (единицы измерения перепутаны, дублирование строк и т.п.) — такие
    случаи помечаются "подозрительное значение" и НЕ попадают в крупные отклонения
    для брифа, но остаются видны в файле для проверки качества данных.
    """
    if plan is None or pd.isna(plan) or plan == 0:
        return None, None, "нет плана", False, False
    if fact is None or pd.isna(fact):
        return None, None, "нет данных", False, False

    deviation_abs = fact - plan
    deviation_pct = deviation_abs / abs(plan)

    is_suspicious = abs(deviation_pct) > max_sane_deviation
    if is_suspicious:
        return round(deviation_abs, 4), round(deviation_pct, 4), \
            "подозрительное значение — проверьте данные", False, True

    is_large = abs(deviation_pct) >= threshold
    if not is_large:
        status = "в пределах нормы"
    elif deviation_pct > 0:
        status = "крупное превышение плана"
    else:
        status = "крупный срыв плана"

    return round(deviation_abs, 4), round(deviation_pct, 4), status, is_large, False


def detect_target_period(df: pd.DataFrame) -> str:
    """Целевой период — самая свежая дата, встречающаяся в данных (по всем показателям
    сразу). Все показатели в отчёте оцениваются именно на этот период — так в одном
    брифе никогда не окажется вперемешку разных месяцев по разным показателям.
    """
    return df["d_date"].astype(str).str.strip().max()


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True)
    parser.add_argument("--sheet", default=0)
    parser.add_argument("--unit-column", default=None)
    parser.add_argument("--metric-column", default="metric_name")
    parser.add_argument("--date-column", default="d_date")
    parser.add_argument("--value-column", default="fact_value")
    parser.add_argument("--plan-column", required=True, help="колонка с плановым значением")
    parser.add_argument("--target-period", default=None,
                         help="какой именно период (месяц) считать 'текущим' для отчёта. "
                              "По умолчанию — самая свежая дата, встречающаяся в данных.")
    parser.add_argument("--recent-months", type=int, default=3,
                         help="сколько последних периодов сохранить в CSV для ручной проверки "
                              "(не влияет на выбор факта для брифа - это делает --target-period)")
    parser.add_argument("--deviation-threshold", type=float, default=0.1,
                         help="относительное отклонение, начиная с которого оно 'крупное' (по умолчанию 0.1)")
    parser.add_argument("--max-sane-deviation", type=float, default=5.0,
                         help="потолок правдоподобия отклонения (по умолчанию 5.0 = 500%%). "
                              "Выше этого — считается ошибкой в данных, не реальной аномалией, "
                              "и не попадает в 'крупные отклонения' для брифа")
    parser.add_argument("--output", required=True)
    parser.add_argument("--sep", default=None)
    args = parser.parse_args()

    df = read_input_auto(args.input, args.sep, args.sheet)

    rename_map = {
        args.metric_column: "metric_name",
        args.date_column: "d_date",
        args.value_column: "fact_value",
        args.plan_column: "plan_value",
    }
    for user_col in rename_map:
        if user_col not in df.columns:
            print(f"Ошибка: колонки '{user_col}' нет в файле. Доступные: {list(df.columns)}", file=sys.stderr)
            sys.exit(1)
    df = df.rename(columns=rename_map)

    if args.unit_column:
        if args.unit_column not in df.columns:
            print(f"Ошибка: колонки '{args.unit_column}' нет в файле.", file=sys.stderr)
            sys.exit(1)
        df = df.rename(columns={args.unit_column: "unit_name"})
    else:
        df["unit_name"] = "_all_"

    df["metric_name"] = df["metric_name"].astype(str).str.strip()
    df["unit_name"] = df["unit_name"].astype(str).str.strip()
    df["d_date"] = df["d_date"].astype(str).str.strip()
    df["fact_value"] = pd.to_numeric(df["fact_value"], errors="coerce")
    df["plan_value"] = pd.to_numeric(df["plan_value"], errors="coerce")

    target_period = args.target_period or detect_target_period(df)
    print(f"Целевой период отчёта: {target_period}", file=sys.stderr)

    results = []
    unique_series = df[["unit_name", "metric_name"]].drop_duplicates().values.tolist()
    print(f"Всего рядов для проверки: {len(unique_series)}", file=sys.stderr)

    skipped_no_target = 0
    for unit, metric in unique_series:
        sub = df[(df["unit_name"] == unit) & (df["metric_name"] == metric)]
        sub = sub.groupby("d_date")[["fact_value", "plan_value"]].sum().sort_index()
        label = f"{unit}:{metric}" if unit != "_all_" else metric

        # классифицируем историю ТОЛЬКО ДО целевого периода включительно (не заглядываем
        # в данные "из будущего" относительно того месяца, который сейчас отчитываем)
        full_classified = []
        for date, row in sub.iterrows():
            if date > target_period:
                continue
            dev_abs, dev_pct, status, is_large, is_suspicious = classify_deviation(
                row["fact_value"], row["plan_value"], args.deviation_threshold, args.max_sane_deviation
            )
            full_classified.append({
                "date": date, "fact_value": row["fact_value"], "plan_value": row["plan_value"],
                "deviation_abs": dev_abs, "deviation_pct": dev_pct,
                "status": status, "is_large_deviation": is_large, "is_suspicious": is_suspicious,
            })

        if not full_classified or full_classified[-1]["date"] != target_period:
            skipped_no_target += 1
            continue  # у показателя нет данных именно за целевой период - пропускаем

        full_streak = compute_full_streak(full_classified)
        streak_may_be_longer = full_streak == len(full_classified) and full_streak > 0

        # в CSV сохраняем несколько последних периодов для ручной проверки,
        # но какой из них ЦЕЛЕВОЙ (и, соответственно, попадёт в бриф) - явно помечено
        recent = full_classified[-args.recent_months:]
        for item in recent:
            results.append({
                "unit_name": unit, "metric_name": metric, "series": label, "date": item["date"],
                "fact_value": item["fact_value"], "plan_value": item["plan_value"],
                "deviation_abs": item["deviation_abs"], "deviation_pct": item["deviation_pct"],
                "status": item["status"], "is_large_deviation": item["is_large_deviation"],
                "is_suspicious": item["is_suspicious"],
                "streak_length": full_streak, "streak_may_be_longer": streak_may_be_longer,
                "is_target_period": item["date"] == target_period,
                "target_period": target_period,
            })

    if skipped_no_target:
        print(f"Пропущено показателей без данных за целевой период {target_period}: {skipped_no_target}",
              file=sys.stderr)

    if not results:
        print("Не найдено ни одной строки для проверки.", file=sys.stderr)
        sys.exit(1)

    result_df = pd.DataFrame(results)
    result_df["_abs_dev"] = result_df["deviation_pct"].abs()
    result_df = result_df.sort_values(["date", "_abs_dev"], ascending=[False, False], na_position="last")
    result_df = result_df.drop(columns=["_abs_dev"])
    result_df.to_csv(args.output, sep=";", index=False, encoding="utf-8-sig")

    n_large = int(result_df["is_large_deviation"].sum())
    n_suspicious = int(result_df["is_suspicious"].sum())
    print(f"Готово. Крупных отклонений: {n_large} из {len(result_df)} проверенных строк. "
          f"Результат: '{args.output}'.", file=sys.stderr)
    if n_suspicious:
        print(f"ВНИМАНИЕ: {n_suspicious} значений помечены как подозрительные "
              f"(отклонение больше {args.max_sane_deviation * 100:.0f}%) — скорее всего, ошибка "
              f"в данных, а не реальная бизнес-аномалия. Они НЕ попадут в бриф автоматически, "
              f"но видны в файле результата (status='подозрительное значение...') — стоит "
              f"проверить исходные данные по этим строкам.", file=sys.stderr)


if __name__ == "__main__":
    main()

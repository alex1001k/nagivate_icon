"""
Ищет аномалии в показателях с помощью прогноза модели Chronos-2 (Amazon) —
предобученная нейросеть для временных рядов, не требует обучения на ваших
данных (zero-shot).

Логика: для каждого показателя, скользящим окном по истории, модель строит
прогноз с доверительным интервалом (квантили) на основе предыдущих периодов.
Если реальное значение вышло за пределы интервала — это аномалия.

ОПТИМИЗАЦИЯ (важно при многих показателях): вместо отдельного вызова модели
на каждый показатель и каждый период, все показатели, находящиеся на одном
и том же "шаге назад от конца своей истории", объединяются в ОДИН запрос
к модели (через параметр id у Chronos-2, который как раз для этого
предназначен). При --check-last-n 3 и 500 показателях это 3 вызова модели
вместо 1500, а не наоборот.

В отличие от VAR, здесь прогноз ПО КАЖДОМУ показателю строится отдельно
(univariate) — группировка из --links-file используется только для того,
чтобы пометить в выводе, какие показатели связаны между собой, для контекста.

Установка перед использованием:
    pip install chronos-forecasting "pandas[pyarrow]"

Запуск:
    python find_chronos_anomalies.py --input fact_pokazateli.csv \\
        --metric-column pokaz_name --date-column date_ --value-column fact \\
        --links-file output_links.csv --output anomalies_chronos.csv

Параметры:
    --input            CSV/Excel с фактами
    --sheet            лист Excel (не используется для CSV)
    --unit-column       (опционально) колонка юнита — если юнита нет, не указывайте
    --metric-column    колонка с названием показателя
    --date-column      колонка с датой/периодом
    --value-column     колонка со значением
    --links-file       CSV из find_metric_links.py — для группировки в выводе
    --model            имя модели на Hugging Face или локальный путь (по умолчанию amazon/chronos-2)
    --context-length   сколько предыдущих периодов видит модель при каждом прогнозе (по умолчанию 8)
    --min-history      минимальное число периодов истории для показателя, чтобы его анализировать.
                        ВАЖНО: должно быть МЕНЬШЕ, чем порог, при котором run_pipeline.py вообще
                        включает Chronos (--min-periods-for-stats) — иначе ни один показатель
                        не пройдёт проверку. По умолчанию 4 (Chronos не требует длинной истории,
                        в отличие от статистических моделей вроде VAR).
    --quantile-low      нижний квантиль интервала (по умолчанию 0.1)
    --quantile-high     верхний квантиль интервала (по умолчанию 0.9)
    --check-last-n      проверять только последние N периодов каждого показателя (по умолчанию 3)
    --batch-size        макс. число показателей в одном запросе к модели (по умолчанию 200,
                        снижайте при нехватке памяти)
    --sep               разделитель CSV (по умолчанию автоопределение)
"""

import argparse
import os
import sys
from collections import defaultdict

import numpy as np
import pandas as pd


def read_input_auto(path: str, sep, sheet=0):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xls"):
        return pd.read_excel(path, sheet_name=sheet)
    if sep:
        return pd.read_csv(path, sep=sep, encoding="utf-8-sig")
    for candidate in (";", ","):
        df = pd.read_csv(path, sep=candidate, encoding="utf-8-sig")
        if df.shape[1] > 1:
            return df
    return df


class UnionFind:
    def __init__(self):
        self.parent = {}

    def find(self, x):
        self.parent.setdefault(x, x)
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[ra] = rb


def build_clusters_from_links(links_path: str):
    links = read_input_auto(links_path, None)
    uf = UnionFind()
    has_group = "group_a" in links.columns and "group_b" in links.columns

    def node_id(row, side):
        if has_group:
            return (str(row[f"group_{side}"]).strip(), str(row[f"metric_{side}"]).strip())
        return (None, str(row[f"metric_{side}"]).strip())

    nodes = set()
    for _, row in links.iterrows():
        a, b = node_id(row, "a"), node_id(row, "b")
        nodes.add(a)
        nodes.add(b)
        uf.union(a, b)

    groups = defaultdict(list)
    for node in nodes:
        groups[uf.find(node)].append(node)
    return list(groups.values())


def load_chronos_pipeline(model_name: str):
    from chronos import Chronos2Pipeline
    print(f"Загружаю модель '{model_name}'...", file=sys.stderr)
    pipeline = Chronos2Pipeline.from_pretrained(model_name, device_map="cpu")
    print("Модель загружена.", file=sys.stderr)
    return pipeline


def batched_forecast(pipeline, batch_items: list, q_low: float, q_high: float):
    """Прогноз на 1 период вперёд СРАЗУ для нескольких рядов одним вызовом модели.

    batch_items: список (id, history_values) — history_values разной длины допустимы,
    Chronos сам обрабатывает ряды разной длины в одном batch-вызове через колонку 'id'.

    Возвращает dict {id: (low, median, high)}.
    """
    rows = []
    for item_id, history in batch_items:
        for t, v in enumerate(history):
            rows.append({"id": item_id, "timestamp": t, "target": v})

    batch_df = pd.DataFrame(rows)
    pred = pipeline.predict_df(
        batch_df, prediction_length=1,
        quantile_levels=[q_low, 0.5, q_high],
        id_column="id", timestamp_column="timestamp", target="target",
    )

    result = {}
    for _, row in pred.iterrows():
        result[row["id"]] = (float(row[str(q_low)]), float(row["0.5"]), float(row[str(q_high)]))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True)
    parser.add_argument("--sheet", default=0)
    parser.add_argument("--unit-column", default=None)
    parser.add_argument("--metric-column", default="metric_name")
    parser.add_argument("--date-column", default="d_date")
    parser.add_argument("--value-column", default="fact_value")
    parser.add_argument("--links-file", default=None, help="CSV из find_metric_links.py — для группировки в выводе")
    parser.add_argument("--output", required=True)
    parser.add_argument("--model", default="amazon/chronos-2")
    parser.add_argument("--context-length", type=int, default=8)
    parser.add_argument("--min-history", type=int, default=4,
                         help="по умолчанию 4 - должно быть меньше --min-periods-for-stats из "
                              "run_pipeline.py, иначе ни один показатель не пройдёт")
    parser.add_argument("--quantile-low", type=float, default=0.1)
    parser.add_argument("--quantile-high", type=float, default=0.9)
    parser.add_argument("--check-last-n", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=200,
                         help="макс. число показателей в одном запросе к модели (по умолчанию 200)")
    parser.add_argument("--sep", default=None)
    args = parser.parse_args()

    df = read_input_auto(args.input, args.sep)

    rename_map = {
        args.metric_column: "metric_name",
        args.date_column: "d_date",
        args.value_column: "fact_value",
    }
    for user_col in rename_map:
        if user_col not in df.columns:
            print(f"Ошибка: колонки '{user_col}' нет в файле. Доступные: {list(df.columns)}", file=sys.stderr)
            sys.exit(1)
    df = df.rename(columns=rename_map)

    if args.unit_column:
        if args.unit_column not in df.columns:
            print(f"Ошибка: колонки '{args.unit_column}' нет в файле.", file=sys.stderr)
            sys.exit(1)
        df = df.rename(columns={args.unit_column: "unit_name"})
    else:
        df["unit_name"] = "_all_"

    df["metric_name"] = df["metric_name"].astype(str).str.strip()
    df["unit_name"] = df["unit_name"].astype(str).str.strip()
    df["d_date"] = df["d_date"].astype(str).str.strip()
    df["fact_value"] = pd.to_numeric(df["fact_value"], errors="coerce")

    target_period = df["d_date"].max()
    print(f"Целевой период отчёта: {target_period}", file=sys.stderr)

    cluster_of = {}
    cluster_members = {}
    if args.links_file:
        clusters = build_clusters_from_links(args.links_file)
        for i, cluster in enumerate(clusters, start=1):
            labels = [f"{u}:{m}" if u else m for u, m in cluster]
            for u, m in cluster:
                cluster_of[(u or "_all_", m)] = i
            cluster_members[i] = ", ".join(labels)
        print(f"Найдено групп из links-file: {len(clusters)}", file=sys.stderr)

    # ── Собираем все ряды, у которых достаточно истории ──
    series_list = []
    unique_series = df[["unit_name", "metric_name"]].drop_duplicates().values.tolist()
    for unit, metric in unique_series:
        sub = df[(df["unit_name"] == unit) & (df["metric_name"] == metric)]
        sub = sub.groupby("d_date")["fact_value"].sum().sort_index()
        dates, values = sub.index.tolist(), sub.values.tolist()
        if len(values) < args.min_history + 1:
            continue
        label = f"{unit}:{metric}" if unit != "_all_" else metric
        series_list.append({
            "unit": unit, "metric": metric, "label": label, "dates": dates, "values": values,
        })

    print(f"Всего рядов для анализа: {len(series_list)} из {len(unique_series)} "
          f"(остальные пропущены - меньше {args.min_history + 1} периодов истории)", file=sys.stderr)
    if not series_list:
        print("Ошибка: ни один показатель не прошёл проверку по минимальной истории "
              f"(--min-history {args.min_history}).", file=sys.stderr)
        sys.exit(1)

    pipeline = load_chronos_pipeline(args.model)

    all_results = []
    # ── Идём по "шагам назад от конца" - одинаковым для всех рядов сразу ──
    # Это и есть оптимизация: на каждом шаге собираем ОДИН батч из всех
    # рядов, которым есть что проверять на этом шаге, вместо отдельного
    # вызова модели на каждый ряд.
    for step in range(args.check_last_n):
        batch_items = []       # (item_id, history) для передачи в модель
        meta_by_id = {}        # item_id -> (series_info, target_date, target_actual)

        for s in series_list:
            values = s["values"]
            t = len(values) - 1 - step
            if t < args.min_history:
                continue
            history = values[max(0, t - args.context_length):t]
            if not history:
                continue
            item_id = f"{s['label']}__{step}"
            batch_items.append((item_id, history))
            meta_by_id[item_id] = (s, s["dates"][t], values[t])

        if not batch_items:
            continue

        print(f"Шаг {step + 1}/{args.check_last_n}: батч из {len(batch_items)} показателей...",
              file=sys.stderr)

        # разбиваем на под-батчи по --batch-size, если показателей очень много
        for start in range(0, len(batch_items), args.batch_size):
            chunk = batch_items[start:start + args.batch_size]
            try:
                forecasts = batched_forecast(pipeline, chunk, args.quantile_low, args.quantile_high)
            except Exception as e:
                print(f"  Предупреждение: батч не удался ({e}), пропускаю эти {len(chunk)} показателей.",
                      file=sys.stderr)
                continue

            for item_id, _ in chunk:
                if item_id not in forecasts:
                    continue
                low, median, high = forecasts[item_id]
                s, date, actual = meta_by_id[item_id]
                is_anomaly = not (low <= actual <= high)
                all_results.append({
                    "date": date, "actual": actual,
                    "forecast_low": round(low, 4), "forecast_median": round(median, 4),
                    "forecast_high": round(high, 4), "is_anomaly": is_anomaly,
                    "series": s["label"],
                    "cluster_id": cluster_of.get((s["unit"], s["metric"])),
                    "cluster_members": cluster_members.get(cluster_of.get((s["unit"], s["metric"])), ""),
                    "is_target_period": date == target_period, "target_period": target_period,
                })

    if not all_results:
        print("Не удалось получить ни одного прогноза.", file=sys.stderr)
        sys.exit(1)

    result_df = pd.DataFrame(all_results)
    result_df = result_df.sort_values(["date", "is_anomaly"], ascending=[False, False])
    result_df.to_csv(args.output, sep=";", index=False, encoding="utf-8-sig")

    n_anom = int(result_df["is_anomaly"].sum())
    print(f"Готово. Аномальных точек: {n_anom} из {len(result_df)}. Результат: '{args.output}'.", file=sys.stderr)


if __name__ == "__main__":
    main()

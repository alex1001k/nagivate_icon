"""
Собирает найденные факты (аномалии из find_var_anomalies.py, связи из
find_metric_links.py) в единый реестр, отбирает самые значимые, строит промпт
для LLM с жёстким контрактом на структурированный вывод (модель ссылается на
факты по id, а не печатает числа сама), проверяет ответ на выдуманные ссылки
и собирает финальный текст брифа — вставляя реальные цифры из реестра, а не
из текста модели.

ВАЖНО: функция call_llm() внизу — ЗАГЛУШКА. Реальный вызов вашей внутренней
LLM нужно подставить самим (это будет обычный POST-запрос на её API — адрес
и формат зависят от того, как она развёрнута: vLLM/TGI/что-то своё).

Запуск:
    python generate_brief.py --anomalies anomalies.csv --links links.csv --output brief.md

Параметры:
    --anomalies      путь к CSV из find_var_anomalies.py
    --links          путь к CSV из find_metric_links.py
    --output         путь к итоговому текстовому брифу (.md)
    --top-anomalies  сколько аномалий включать в бриф (по умолчанию 5)
    --top-links      сколько связей включать в бриф (по умолчанию 3)
    --min-similarity минимальная схожесть связи, чтобы попасть в отбор (по умолчанию 0.75)
    --dry-run        не вызывать LLM, только показать собранный промпт и факты
"""

import argparse
import json
import os
import re
import sys

import pandas as pd


def read_text_auto_encoding(path: str) -> str:
    """Читает текстовый файл, пробуя несколько кодировок по очереди.

    Нужна для файлов, куда вставляют ответ LLM вручную через разные
    редакторы (Блокнот и т.п.) — они не всегда сохраняют в UTF-8,
    особенно на Windows с русским текстом (частая кодировка — cp1251).
    """
    for encoding in ("utf-8-sig", "utf-8", "cp1251", "latin-1"):
        try:
            with open(path, "r", encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Не удалось прочитать '{path}' ни в одной из известных кодировок "
                      f"(utf-8-sig, utf-8, cp1251, latin-1). Пересохраните файл в UTF-8.")


# ────────────────────────────────────────────────────────────────────────────
# 1. Сборка единого реестра фактов из разных источников
# ────────────────────────────────────────────────────────────────────────────

def pick_representative_per_series(df: pd.DataFrame, sort_key_col: str, top_n: int):
    """Группирует строки по 'series', оставляет ОДНУ строку на показатель — с самым
    ПОЗДНИМ периодом среди отклонений (а не с самой крупной величиной отклонения).
    Это сделано намеренно: если у одного показателя "рекордный" месяц был в феврале,
    а у другого — в апреле, объединять их в одном брифе как будто это про одно и то
    же время — вводит в заблуждение. Беря самый свежий период у каждого, показатели
    в итоговом брифе, как правило, ссылаются на один и тот же месяц.

    Возвращает список (представительная_строка, occurrences) длиной <= top_n,
    отсортированный по убыванию значимости представительной строки.
    """
    groups = []
    for series, sub in df.groupby("series"):
        idx = sub["date"].idxmax()  # самый поздний период среди отклонений этого показателя
        representative = sub.loc[idx]
        occurrences = len(sub)
        groups.append((representative, occurrences))

    groups.sort(key=lambda pair: abs(pair[0][sort_key_col]), reverse=True)
    return groups[:top_n]


def build_facts_from_anomalies(anomalies_path: str, top_n: int):
    """Понимает ДВА формата вывода:
      - find_var_anomalies.py: колонки date, series, residual, zscore, is_anomaly...
      - find_chronos_anomalies.py: колонки date, actual, forecast_low/median/high, is_anomaly...

    Один показатель даёт РОВНО ОДИН факт — за целевой период отчёта (is_target_period),
    один и тот же календарный месяц для всех показателей сразу (а не "самый значимый
    период" индивидуально для каждого — иначе в одном брифе перемешивались бы разные месяцы).
    """
    df = pd.read_csv(anomalies_path, sep=";", encoding="utf-8-sig")
    df = df[df["is_anomaly"] == True].copy()  # noqa: E712
    if df.empty:
        return []

    has_target_col = "is_target_period" in df.columns
    if has_target_col:
        df = df[df["is_target_period"] == True].copy()  # noqa: E712
        if df.empty:
            return []

    facts = []

    if "zscore" in df.columns:
        rows = df if has_target_col else [r for r, _ in pick_representative_per_series(df, "zscore", top_n)]
        if has_target_col:
            df["_abs"] = df["zscore"].abs()
            rows = [r for _, r in df.sort_values("_abs", ascending=False).head(top_n).iterrows()]
        for row in rows:
            facts.append({
                "fact_type": "anomaly_var",
                "entities": [row["series"]],
                "period": row["date"],
                "value_summary": {"zscore": row["zscore"], "residual": row["residual"]},
                "confidence": min(abs(row["zscore"]) / 5.0, 1.0),
                "display": f"{row['series']} за {row['date']}: отклонение z={row['zscore']:.2f} "
                           f"(ожидалось иное с учётом связанных показателей: {row['cluster_members']})",
            })

    elif "forecast_low" in df.columns:
        interval_width = (df["forecast_high"] - df["forecast_low"]).clip(lower=1e-9)
        df["_dev"] = (df["actual"] - df["forecast_median"]) / interval_width
        if has_target_col:
            rows = [r for _, r in df.sort_values("_dev", key=lambda s: s.abs(), ascending=False).head(top_n).iterrows()]
        else:
            rows = [r for r, _ in pick_representative_per_series(df, "_dev", top_n)]
        for row in rows:
            facts.append({
                "fact_type": "anomaly_chronos",
                "entities": [row["series"]],
                "period": row["date"],
                "value_summary": {
                    "actual": row["actual"], "forecast_low": row["forecast_low"],
                    "forecast_median": row["forecast_median"], "forecast_high": row["forecast_high"],
                },
                "confidence": min(abs(float(row["_dev"])) / 3.0, 1.0),
                "display": f"{row['series']} за {row['date']}: факт {format_number_human(row['actual'])}, "
                           f"ожидался диапазон {format_number_human(row['forecast_low'])}"
                           f"–{format_number_human(row['forecast_high'])} "
                           f"(группа: {row.get('cluster_members', '')})",
            })
    else:
        print(f"Предупреждение: не удалось распознать формат '{anomalies_path}' "
              f"(нет ни 'zscore', ни 'forecast_low').", file=sys.stderr)

    return facts


def build_facts_from_plan_deviations(deviations_path: str, top_n: int):
    """Читает результат find_plan_deviations.py — крупные отклонения факта
    от плана. Это ПЕРВИЧНЫЙ тип факта: отбирается раньше связей, потому что
    связи подключаются только вокруг уже найденных отклонений.

    Один показатель даёт РОВНО ОДИН факт — за целевой период отчёта
    (is_target_period), один и тот же календарный месяц для ВСЕХ показателей,
    а не "самый худший месяц" для каждого по отдельности (иначе в одном
    брифе перемешивались бы разные месяцы у разных показателей).
    """
    df = pd.read_csv(deviations_path, sep=";", encoding="utf-8-sig")

    if "is_target_period" in df.columns:
        df = df[(df["is_target_period"] == True) & (df["is_large_deviation"] == True)].copy()  # noqa: E712
    else:
        # старый формат CSV (до введения единого целевого периода) - откат на прежнее поведение
        df = df[df["is_large_deviation"] == True].copy()  # noqa: E712
        if not df.empty:
            df = pd.concat([g.loc[[g["deviation_pct"].abs().idxmax()]] for _, g in df.groupby("series")])

    if df.empty:
        return []

    df["_abs_dev"] = df["deviation_pct"].abs()
    df = df.sort_values("_abs_dev", ascending=False).head(top_n)

    facts = []
    for _, row in df.iterrows():
        direction = "выше" if row["deviation_pct"] > 0 else "ниже"

        streak_n = int(row["streak_length"]) if "streak_length" in row and pd.notna(row["streak_length"]) else 1
        may_be_longer = bool(row.get("streak_may_be_longer", False))

        if streak_n > 1:
            longer_note = " (это минимум — доступной истории не хватает, чтобы увидеть начало серии)" \
                if may_be_longer else ""
            streak_note = f"{streak_n} мес. подряд{longer_note}"
        else:
            streak_note = "разовое отклонение в этом периоде"

        facts.append({
            "fact_type": "plan_deviation",
            "entities": [row["series"]],
            "period": row["date"],
            "value_summary": {
                "fact_value": row["fact_value"], "plan_value": row["plan_value"],
                "deviation_pct": row["deviation_pct"], "direction": direction,
                "streak_length": streak_n, "streak_note": streak_note,
            },
            "confidence": min(abs(row["deviation_pct"]) / 0.5, 1.0),
            "display": f"{row['series']} за {row['date']}: факт {row['fact_value']:.1f} "
                       f"{direction} плана {row['plan_value']:.1f} на {abs(row['deviation_pct']) * 100:.0f}% "
                       f"({streak_note})",
        })
    return facts


def build_related_context_facts(primary_facts: list, links_path: str,
                                 max_related_per_entity: int = 2, min_similarity: float = 0.75):
    """Подтягивает связанные показатели ТОЛЬКО для тех сущностей, что уже
    попали в primary_facts (например, отклонения от плана) — а не как
    независимый отдельный топ-N по всем связям. Это и есть порядок
    "сначала находим отклонения, потом смотрим, что с ними связано".
    """
    if not primary_facts:
        return []

    entities_of_interest = {e for f in primary_facts for e in f["entities"]}

    df = pd.read_csv(links_path, sep=";", encoding="utf-8-sig")
    df = df[df["similarity"] >= min_similarity].copy()
    has_group = "group_a" in df.columns

    def label(row, side):
        if has_group:
            g = row[f"group_{side}"]
            m = row[f"metric_{side}"]
            return f"{g}: {m}" if g else m
        return row[f"metric_{side}"]

    facts = []
    count_per_entity = {}
    for _, row in df.sort_values("similarity", ascending=False).iterrows():
        a, b = label(row, "a"), label(row, "b")
        for anchor, other in ((a, b), (b, a)):
            if anchor not in entities_of_interest:
                continue
            if count_per_entity.get(anchor, 0) >= max_related_per_entity:
                continue
            count_per_entity[anchor] = count_per_entity.get(anchor, 0) + 1
            facts.append({
                "fact_type": "link_context",
                "entities": [anchor, other],
                "period": None,
                "value_summary": {"similarity": row["similarity"], "related_to": anchor},
                "confidence": row["similarity"],
                "display": f"'{other}' семантически похож на '{anchor}' (схожесть {row['similarity']:.2f}) "
                           f"— контекст к найденному отклонению, не причина",
            })
    return facts


def build_facts_from_links(links_path: str, top_n: int, min_similarity: float):
    """Старый режим — независимый топ-N по всем связям, без привязки
    к отклонениям. Оставлен для обратной совместимости, если используется
    без --plan-deviations."""
    df = pd.read_csv(links_path, sep=";", encoding="utf-8-sig")
    df = df[df["similarity"] >= min_similarity].copy()
    df = df.sort_values("similarity", ascending=False).head(top_n)

    has_group = "group_a" in df.columns

    facts = []
    for _, row in df.iterrows():
        if has_group:
            a = f"{row['group_a']}: {row['metric_a']}" if row["group_a"] else row["metric_a"]
            b = f"{row['group_b']}: {row['metric_b']}" if row["group_b"] else row["metric_b"]
        else:
            a, b = row["metric_a"], row["metric_b"]

        facts.append({
            "fact_type": "link_semantic",
            "entities": [a, b],
            "period": None,
            "value_summary": {"similarity": row["similarity"]},
            "confidence": row["similarity"],
            "display": f"'{a}' и '{b}' семантически похожи (схожесть {row['similarity']:.2f}) — "
                       f"наблюдение, не доказанная причинно-следственная связь",
        })
    return facts


def assign_fact_ids(facts: list):
    for i, f in enumerate(facts, start=1):
        f["fact_id"] = f"f_{i:03d}"
    return facts


# ────────────────────────────────────────────────────────────────────────────
# 2. Построение промпта с жёстким контрактом на вывод
# ────────────────────────────────────────────────────────────────────────────

PROMPT_TEMPLATE = """Ты аналитик, который пишет бриф по отклонениям бизнес-показателей. Бриф читают
люди, которым нужно быстро понять картину, а не список одинаковых пунктов — пиши как живой
аналитик, а не как шаблон.

ПРАВИЛА (обязательны):
1. Используй ТОЛЬКО факты из списка ниже. Не добавляй никаких цифр, дат или названий, которых нет в списке.
2. Придумай короткий ЗАГОЛОВОК (title) — 1 предложение, отражающее главный сюжет периода
   (например, самое крупное отклонение или общую тенденцию), а не просто "Отчёт за такой-то период".
3. Каждый сегмент бриф может ссылаться на ОДИН факт ИЛИ на НЕСКОЛЬКО фактов сразу — используй это!
   Если у отклонения есть связанные показатели (тип "link_context") — ОБЪЕДИНЯЙ их в ОДНО связное
   предложение вместе с этим отклонением (не выноси в отдельный оторванный пункт). Пример того,
   что нужно: "Показатель А сильно провалился, и похожий на него показатель Б тоже вне нормы" —
   ОДИН сегмент с fact_ids обоих фактов, а не два раздельных.
4. ЦЕЛЕВОЕ ЧИСЛО СЕГМЕНТОВ (записок) В ИТОГЕ: примерно 10-20, независимо от того, сколько фактов
   ниже (может быть и 30, и 40). Это значит:
   - НЕ создавай отдельный сегмент на КАЖДЫЙ факт по отдельности, если фактов больше 20 —
     сворачивай похожие/менее значимые отклонения (близкие по величине, из одного юнита,
     мелкие) в одну записку-перечисление ("ещё три показателя Юнита Б тоже не выполнили план: ...").
   - НО и не сжимай всё в 1-2 гигантских абзаца — каждая записка должна оставаться отдельной,
     читаемой темой (одно отклонение или один тесный кластер из 2-3 связанных фактов), а не
     свалкой из десяти разных показателей в одном предложении.
   - Самые крупные/значимые отклонения (по величине) заслуживают СВОЕЙ отдельной записки с деталями;
     мелкие и однотипные — можно сгруппировать вместе. Не жертвуй ни одним фактом молча —
     каждый факт должен быть упомянут хотя бы в одном сегменте (ссылкой fact_ids), пусть даже
     в составе группового перечисления.
5. РАЗНООБРАЗЬ ФОРМУЛИРОВКИ. Не начинай разные сегменты одинаковыми словами
   ("Зафиксировано отклонение...", "Обнаружено отклонение..." для каждого пункта — это плохо).
   Используй разные конструкции: где-то констатация, где-то сравнение, где-то вопрос-переход
   ("а что с..."), где-то через объединение похожих случаев.
6. Не пиши сами числа в тексте. Вместо этого в том месте, где по смыслу должна быть цифра,
   вставь плейсхолдер вида {{f_001}} (используй ТОТ ЖЕ fact_id, что и в fact_ids этого сегмента) —
   код сам заменит его на реальное значение прямо в этом месте текста. Пример:
   narrative: "месячная аудитория снизилась {{f_001}}, а число жалоб выросло {{f_002}}"
   Плейсхолдер можно поставить в середине предложения, не обязательно в конце.
   Если факт упомянут в fact_ids, но по смыслу цифра ему не нужна нигде в тексте — ничего
   страшного, но старайся ставить плейсхолдер для каждого упомянутого факта хотя бы один раз.
7. Факты типа "plan_deviation" и "anomaly_*" — подтверждённые отклонения, формулируй уверенно.
   Факты типа "link_semantic" и "link_context" — это СЕМАНТИЧЕСКОЕ НАБЛЮДЕНИЕ (похожесть названий),
   не причинно-следственная связь. Формулируй как контекст/фон ("похожий показатель тоже..."),
   никогда как объяснение причины отклонения.
8. Верни ТОЛЬКО валидный JSON как обычный текстовый (plain text) ответ:
   - без markdown-разметки и без блоков ```;
   - без пояснений, комментариев или заголовков до или после JSON;
   - первый символ твоего ответа должен быть "{{", последний — "}}";
   - без невидимых служебных символов в начале (например, BOM/zero-width space).
9. Этот ответ будет сохранён пользователем в файл response_brief.json — отвечай так,
   как будто ты формируешь содержимое именно этого файла, а не сообщение в чате.

Формат ответа:
{{
  "title": "короткий заголовок, отражающий главный сюжет периода",
  "segments": [
    {{"fact_ids": ["f_001"], "narrative": "связный текст на русском без чисел"}},
    {{"fact_ids": ["f_002", "f_006"], "narrative": "текст, объединяющий сразу два факта (например, отклонение + связанный показатель)"}},
    ...
  ]
}}

Факты:
{facts_json}
"""


def compute_brief_period(facts: list):
    """Определяет ОБЩИЙ период брифа - самая частая дата среди первичных фактов
    (отклонений). Передаётся в промпт, чтобы LLM использовала именно её в
    заголовке, а не смешивала разные месяцы в одном сюжете."""
    from collections import Counter
    periods = [f["period"] for f in facts
               if f["fact_type"] in PRIMARY_TYPES and f.get("period")]
    if not periods:
        return None
    return Counter(periods).most_common(1)[0][0]


def build_prompt(facts: list, brief_period: str = None) -> str:
    facts_for_prompt = [
        {"fact_id": f["fact_id"], "type": f["fact_type"], "entities": f["entities"], "period": f["period"]}
        for f in facts
    ]
    period_hint = (
        f"\nОБЩИЙ ПЕРИОД ЭТОГО БРИФА: {brief_period}. Используй именно эту дату в заголовке "
        f"(например, в конце заголовка через запятую). Если у какого-то факта период отличается "
        f"от этого — не объединяй его в одно предложение с фактами за {brief_period}, "
        f"упоминай отдельно с указанием его собственного периода.\n"
        if brief_period else ""
    )
    return PROMPT_TEMPLATE.format(facts_json=json.dumps(facts_for_prompt, ensure_ascii=False, indent=2)) + period_hint


# ────────────────────────────────────────────────────────────────────────────
# 3. Вызов LLM — ЗАГЛУШКА, замените на вызов вашей внутренней модели
# ────────────────────────────────────────────────────────────────────────────

def call_llm(prompt: str, api_base: str, api_key: str = None, model_name: str = "default",
             temperature: float = 0.7, timeout: int = 120) -> str:
    """Вызывает LLM через OpenAI-совместимый эндпоинт (стандарт для vLLM/TGI и подобных
    внутренних развёртываний). Если ваш API устроен иначе — поправьте эту функцию:
    именно здесь единственное место, где формируется запрос и разбирается ответ.
    """
    import requests

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    resp = requests.post(
        api_base.rstrip("/") + "/chat/completions" if not api_base.rstrip("/").endswith("/chat/completions")
        else api_base,
        headers=headers,
        json={
            "model": model_name,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
        },
        timeout=timeout,
    )
    resp.raise_for_status()
    data = resp.json()
    return data["choices"][0]["message"]["content"]


# ────────────────────────────────────────────────────────────────────────────
# 4. Валидация ответа — проверка, что все fact_id реальны
# ────────────────────────────────────────────────────────────────────────────

def validate_llm_output(raw_response: str, facts_by_id: dict):
    """Парсит JSON от LLM, отбрасывает сегменты со ссылкой хотя бы на один
    несуществующий факт (весь сегмент целиком, а не только плохую ссылку —
    чтобы не публиковать текст, частично опирающийся на выдуманное).

    Поддерживает и новый формат ("fact_ids": [...]), и старый ("fact_id": "..."),
    для обратной совместимости с уже сохранёнными промптами/ответами.

    Возвращает (title, valid_segments, rejected_segments).
    """
    cleaned = re.sub(r"^```(json)?|```$", "", raw_response.strip(), flags=re.MULTILINE).strip()
    cleaned = cleaned.lstrip("\ufeff")  # BOM не убирается обычным .strip(), убираем явно
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise ValueError(f"LLM вернула невалидный JSON: {e}\nОтвет был:\n{raw_response}")

    title = data.get("title", "").strip()

    valid, rejected = [], []
    for seg in data.get("segments", []):
        fids = seg.get("fact_ids")
        if fids is None:
            single = seg.get("fact_id")
            fids = [single] if single else []
        seg["fact_ids"] = fids  # нормализуем на будущее, независимо от исходного формата

        if fids and all(fid in facts_by_id for fid in fids):
            valid.append(seg)
        else:
            rejected.append(seg)
    return title, valid, rejected


# ────────────────────────────────────────────────────────────────────────────
# 5. Рендер финального текста — реальные цифры подставляет КОД, не LLM
# ────────────────────────────────────────────────────────────────────────────

def format_number_human(value) -> str:
    """Превращает число в компактный, понятный человеку вид: 15000000 -> '15 млн',
    150000 -> '150 тыс', 42.7 -> '42.7', 100.0 -> '100' (без лишних нулей)."""
    v = float(value)
    sign = "-" if v < 0 else ""
    av = abs(v)

    def _trim(x):
        return f"{x:.0f}" if abs(x - round(x)) < 0.05 else f"{x:.1f}"

    if av >= 1e9:
        return f"{sign}{_trim(av / 1e9)} млрд"
    if av >= 1e6:
        return f"{sign}{_trim(av / 1e6)} млн"
    if av >= 1e3:
        return f"{sign}{_trim(av / 1e3)} тыс"
    return f"{sign}{_trim(av)}"


def format_value(fact: dict) -> str:
    if fact["fact_type"] == "anomaly_var":
        return f"(z-score {fact['value_summary']['zscore']:.2f})"

    if fact["fact_type"] == "anomaly_chronos":
        v = fact["value_summary"]
        low, high = v["forecast_low"], v["forecast_high"]
        actual_h = format_number_human(v["actual"])
        # если границы интервала практически совпадают - не изображаем "диапазон" из двух
        # одинаковых чисел, просто называем одно ожидаемое значение
        if abs(high - low) < max(abs(high), abs(low), 1) * 0.02:
            expected = format_number_human((low + high) / 2)
            return f"(факт {actual_h}, ожидалось {expected})"
        return f"(факт {actual_h}, ожидалось {format_number_human(low)}–{format_number_human(high)})"

    if fact["fact_type"] == "plan_deviation":
        v = fact["value_summary"]
        return (f"(факт {format_number_human(v['fact_value'])} vs план {format_number_human(v['plan_value'])}, "
                f"отклонение {v['deviation_pct'] * 100:+.0f}%)")

    if fact["fact_type"] in ("link_semantic", "link_context"):
        return f"(схожесть {fact['value_summary']['similarity']:.2f})"
    return ""


PRIMARY_TYPES = ("plan_deviation", "anomaly_var", "anomaly_chronos")
CONTEXT_TYPES = ("link_context", "link_semantic")


def render_segment_text(narrative: str, fact_ids: list, facts_by_id: dict) -> str:
    """Подставляет реальные значения на место плейсхолдеров {fact_id} внутри текста,
    там, где их поставила LLM. Если для какого-то факта плейсхолдера в тексте не
    нашлось (модель забыла) - его значение всё равно добавляется в конец строки,
    чтобы ни один факт не терялся молча."""
    text = narrative
    used = set()
    for fid in fact_ids:
        placeholder = "{" + fid + "}"
        if placeholder in text:
            text = text.replace(placeholder, format_value(facts_by_id[fid]))
            used.add(fid)

    leftover = [fid for fid in fact_ids if fid not in used]
    if leftover:
        extra = " ".join(format_value(facts_by_id[fid]) for fid in leftover)
        text = f"{text} {extra}".rstrip()
    return text


def render_brief(title: str, valid_segments: list, facts_by_id: dict) -> str:
    """Собирает финальный текст.

    Теперь сегмент может ссылаться на НЕСКОЛЬКО fact_id сразу — LLM поощряется
    сама объединять отклонение с его связанным показателем в одно предложение
    (см. правило 3 промпта). Если модель всё же оставила связь отдельным
    сегментом — код подстраховывает и вкладывает такой сегмент под нужным
    отклонением по совпадению сущностей, как и раньше.
    """
    fact_id_order = {fid: i for i, fid in enumerate(facts_by_id)}

    def seg_types(seg):
        return [facts_by_id[fid]["fact_type"] for fid in seg["fact_ids"]]

    primary_segments = [s for s in valid_segments if any(t in PRIMARY_TYPES for t in seg_types(s))]
    context_only_segments = [s for s in valid_segments if s not in primary_segments]

    def seg_rank(seg):
        primary_fids = [fid for fid in seg["fact_ids"] if facts_by_id[fid]["fact_type"] in PRIMARY_TYPES]
        return min((fact_id_order[fid] for fid in primary_fids), default=10 ** 9)

    primary_segments.sort(key=seg_rank)

    lines = []
    if title:
        lines.append(f"# {title}\n")

    placed_context_idx = set()

    for pseg in primary_segments:
        text = render_segment_text(pseg.get("narrative", "").strip(), pseg["fact_ids"], facts_by_id)
        lines.append(f"- {text}")

        primary_entities = set()
        for fid in pseg["fact_ids"]:
            if facts_by_id[fid]["fact_type"] in PRIMARY_TYPES:
                primary_entities.update(facts_by_id[fid]["entities"])

        for idx, cseg in enumerate(context_only_segments):
            if idx in placed_context_idx:
                continue
            related_tos = {
                facts_by_id[fid]["value_summary"].get("related_to")
                for fid in cseg["fact_ids"] if facts_by_id[fid]["fact_type"] in CONTEXT_TYPES
            }
            if related_tos & primary_entities:
                ctext = render_segment_text(cseg.get("narrative", "").strip(), cseg["fact_ids"], facts_by_id)
                lines.append(f"    · {ctext}")
                placed_context_idx.add(idx)

    leftover = [cseg for idx, cseg in enumerate(context_only_segments) if idx not in placed_context_idx]
    if leftover:
        lines.append("\nДополнительный контекст (связи без явной привязки к конкретному отклонению):")
        for cseg in leftover:
            ctext = render_segment_text(cseg.get("narrative", "").strip(), cseg["fact_ids"], facts_by_id)
            lines.append(f"- {ctext}")

    return "\n".join(lines)


# ────────────────────────────────────────────────────────────────────────────
# main
# ────────────────────────────────────────────────────────────────────────────

def send_email_brief(to_email: str, subject: str, body_text: str,
                      smtp_host: str, smtp_port: int, smtp_user: str, smtp_password: str,
                      smtp_from: str = None, use_tls: bool = True):
    """Отправляет готовый текст брифа на почту через обычный SMTP.

    Не требует стороннего сервиса — только доступ к вашему SMTP-серверу
    (тот же, что используется для рабочей почты). Если сервер требует другую
    схему авторизации/порт — измените параметры при вызове (--smtp-*).
    """
    import smtplib
    from email.mime.text import MIMEText

    msg = MIMEText(body_text, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = smtp_from or smtp_user or "noreply@localhost"
    msg["To"] = to_email

    with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as server:
        if use_tls:
            server.starttls()
        if smtp_user and smtp_password:
            server.login(smtp_user, smtp_password)
        server.sendmail(msg["From"], [to_email], msg.as_string())


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--anomalies", default=None,
                         help="CSV из find_var_anomalies.py / find_chronos_anomalies.py (опционально)")
    parser.add_argument("--plan-deviations", default=None,
                         help="CSV из find_plan_deviations.py — крупные отклонения факта от плана (опционально)")
    parser.add_argument("--links", default=None,
                         help="CSV из find_metric_links.py — подключается КАК КОНТЕКСТ уже "
                              "после отбора отклонений/аномалий, не как независимый источник фактов")
    parser.add_argument("--output", required=True, help="путь к итоговому .md брифу")
    parser.add_argument("--top-anomalies", type=int, default=5)
    parser.add_argument("--top-plan-deviations", type=int, default=20,
                         help="сколько крупных отклонений от плана включать в бриф (по умолчанию 20 — "
                              "почти все реальные отклонения за 2-3 месяца обычно укладываются в это число)")
    parser.add_argument("--max-related-per-entity", type=int, default=2,
                         help="сколько связанных показателей подтягивать на каждое найденное "
                              "отклонение (по умолчанию 2)")
    parser.add_argument("--min-similarity", type=float, default=0.75,
                         help="минимальная схожесть, чтобы связь попала в контекст брифа")
    parser.add_argument("--dry-run", action="store_true", help="не вызывать LLM, только показать промпт и факты")
    parser.add_argument("--save-prompt", default=None,
                         help="сохранить промпт в текстовый файл — чтобы скопировать его в чат LLM руками")
    parser.add_argument("--response-file", default=None,
                         help="путь к файлу, куда вы вставили ответ LLM (ручной режим, без API)")
    parser.add_argument("--api-base", default=None,
                         help="адрес API вашей LLM (например http://адрес:порт/v1) — включает прямой вызов "
                              "вместо ручного копипаста через чат")
    parser.add_argument("--api-key", default=None, help="API-ключ/токен, если требуется")
    parser.add_argument("--model-name", default="default", help="имя модели для поля 'model' в запросе")
    parser.add_argument("--email", default=None,
                         help="email получателя - если указан, готовый бриф отправится на эту почту")
    parser.add_argument("--smtp-host", default=None, help="адрес SMTP-сервера")
    parser.add_argument("--smtp-port", type=int, default=587, help="порт SMTP (по умолчанию 587, STARTTLS)")
    parser.add_argument("--smtp-user", default=None, help="логин для SMTP-авторизации")
    parser.add_argument("--smtp-password", default=None,
                         help="пароль для SMTP (лучше передавать через переменную окружения "
                              "SMTP_PASSWORD, а не в открытом виде в команде)")
    parser.add_argument("--smtp-from", default=None, help="адрес отправителя (по умолчанию = smtp-user)")
    parser.add_argument("--no-smtp-tls", dest="smtp_tls", action="store_false", default=True,
                         help="отключить STARTTLS, если сервер работает без шифрования")
    args = parser.parse_args()

    if args.smtp_password is None:
        args.smtp_password = os.environ.get("SMTP_PASSWORD")

    if not args.anomalies and not args.plan_deviations:
        print("Ошибка: укажите хотя бы один источник первичных фактов — "
              "--anomalies и/или --plan-deviations.", file=sys.stderr)
        sys.exit(1)

    # ── Шаг 1: первичные факты (отклонения/аномалии) — отбираются раньше связей ──
    primary_facts = []
    if args.anomalies:
        primary_facts += build_facts_from_anomalies(args.anomalies, args.top_anomalies)
    if args.plan_deviations:
        primary_facts += build_facts_from_plan_deviations(args.plan_deviations, args.top_plan_deviations)

    if not primary_facts:
        print("Нет фактов для брифа (нет аномалий/отклонений выше порогов).", file=sys.stderr)
        sys.exit(0)

    # ── Шаг 2: связи подключаются ТОЛЬКО вокруг уже найденных отклонений ──
    context_facts = []
    if args.links:
        context_facts = build_related_context_facts(
            primary_facts, args.links,
            max_related_per_entity=args.max_related_per_entity, min_similarity=args.min_similarity,
        )

    facts = assign_fact_ids(primary_facts + context_facts)

    print(f"Собрано фактов: {len(facts)} (первичных: {len(primary_facts)}, контекст-связей: {len(context_facts)})",
          file=sys.stderr)
    for f in facts:
        print(f"  [{f['fact_id']}] {f['display']}", file=sys.stderr)

    facts_by_id = {f["fact_id"]: f for f in facts}
    periods_present = {f["period"] for f in primary_facts if f.get("period")}
    brief_period = periods_present.pop() if len(periods_present) == 1 else None
    if len(periods_present) > 1:
        print(f"ВНИМАНИЕ: первичные факты относятся к разным периодам {periods_present} — "
              f"обычно это означает разные --target-period в разных скриптах детекции. "
              f"Заголовок брифа не будет содержать общую дату.", file=sys.stderr)

    prompt = build_prompt(facts, brief_period)

    if args.save_prompt:
        with open(args.save_prompt, "w", encoding="utf-8") as f:
            f.write(prompt)
        print(f"Промпт сохранён в '{args.save_prompt}' — откройте файл, скопируйте всё содержимое "
              f"и вставьте в чат вашей LLM.", file=sys.stderr)

    if args.dry_run:
        print("\n──── ПРОМПТ (dry-run, LLM не вызывается) ────\n", file=sys.stderr)
        print(prompt)
        return

    # ── Ручной режим: ответ LLM уже лежит в файле (вставили сами из чата) ──
    if args.response_file:
        raw_response = read_text_auto_encoding(args.response_file)
        print(f"Читаю ответ LLM из '{args.response_file}'...", file=sys.stderr)
    elif args.api_base:
        # ── Автоматический режим: прямой вызов через API ──
        print(f"Вызываю LLM напрямую через {args.api_base}...", file=sys.stderr)
        raw_response = call_llm(prompt, api_base=args.api_base, api_key=args.api_key,
                                 model_name=args.model_name)
    else:
        print("Ошибка: укажите либо --response-file (ручной режим), либо --api-base (прямой вызов), "
              "либо --dry-run.", file=sys.stderr)
        sys.exit(1)

    title, valid_segments, rejected = validate_llm_output(raw_response, facts_by_id)

    if rejected:
        print(f"ВНИМАНИЕ: отклонено {len(rejected)} сегментов со ссылкой на несуществующий факт "
              f"(возможная галлюцинация): {rejected}", file=sys.stderr)

    if not valid_segments:
        print("Ни один сегмент не прошёл валидацию — бриф не сформирован.", file=sys.stderr)
        sys.exit(1)

    brief_text = render_brief(title, valid_segments, facts_by_id)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"{brief_text}\n")

    print(f"Готово. Бриф сохранён в '{args.output}' ({len(valid_segments)} сегментов, "
          f"заголовок: '{title}').", file=sys.stderr)

    if args.email:
        if not args.smtp_host:
            print("Ошибка: указан --email, но не указан --smtp-host — письмо не отправлено. "
                  "Нужен адрес вашего SMTP-сервера (уточните у ИТ/инфраструктурной команды).",
                  file=sys.stderr)
            sys.exit(1)
        try:
            send_email_brief(
                to_email=args.email,
                subject=title or "Автоматический бриф",
                body_text=brief_text,
                smtp_host=args.smtp_host, smtp_port=args.smtp_port,
                smtp_user=args.smtp_user, smtp_password=args.smtp_password,
                smtp_from=args.smtp_from, use_tls=args.smtp_tls,
            )
            print(f"Письмо отправлено на {args.email}.", file=sys.stderr)
        except Exception as e:
            print(f"ОШИБКА при отправке письма на {args.email}: {e}", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()

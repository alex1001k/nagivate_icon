"""
Собирает найденные факты (аномалии из find_var_anomalies.py, связи из
find_metric_links.py) в единый реестр, отбирает самые значимые, строит промпт
для LLM с жёстким контрактом на структурированный вывод (модель ссылается на
факты по id, а не печатает числа сама), проверяет ответ на выдуманные ссылки
и собирает финальный текст брифа — вставляя реальные цифры из реестра, а не
из текста модели.

ВАЖНО: функция call_llm() внизу — ЗАГЛУШКА. Реальный вызов вашей внутренней
LLM нужно подставить самим (это будет обычный POST-запрос на её API — адрес
и формат зависят от того, как она развёрнута: vLLM/TGI/что-то своё).

Запуск:
    python generate_brief.py --anomalies anomalies.csv --links links.csv --output brief.md

Параметры:
    --anomalies      путь к CSV из find_var_anomalies.py
    --links          путь к CSV из find_metric_links.py
    --output         путь к итоговому текстовому брифу (.md)
    --top-anomalies  сколько аномалий включать в бриф (по умолчанию 5)
    --top-links      сколько связей включать в бриф (по умолчанию 3)
    --min-similarity минимальная схожесть связи, чтобы попасть в отбор (по умолчанию 0.75)
    --dry-run        не вызывать LLM, только показать собранный промпт и факты
"""

import argparse
import json
import re
import sys

import pandas as pd


def read_text_auto_encoding(path: str) -> str:
    """Читает текстовый файл, пробуя несколько кодировок по очереди.

    Нужна для файлов, куда вставляют ответ LLM вручную через разные
    редакторы (Блокнот и т.п.) — они не всегда сохраняют в UTF-8,
    особенно на Windows с русским текстом (частая кодировка — cp1251).
    """
    for encoding in ("utf-8-sig", "utf-8", "cp1251", "latin-1"):
        try:
            with open(path, "r", encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Не удалось прочитать '{path}' ни в одной из известных кодировок "
                      f"(utf-8-sig, utf-8, cp1251, latin-1). Пересохраните файл в UTF-8.")


# ────────────────────────────────────────────────────────────────────────────
# 1. Сборка единого реестра фактов из разных источников
# ────────────────────────────────────────────────────────────────────────────

def build_facts_from_anomalies(anomalies_path: str, top_n: int):
    """Понимает ДВА формата вывода:
      - find_var_anomalies.py: колонки date, series, residual, zscore, is_anomaly...
      - find_chronos_anomalies.py: колонки date, actual, forecast_low/median/high, is_anomaly...
    """
    df = pd.read_csv(anomalies_path, sep=";", encoding="utf-8-sig")
    df = df[df["is_anomaly"] == True].copy()  # noqa: E712

    facts = []

    if "zscore" in df.columns:
        # ── формат VAR ──
        df["_sort_key"] = df["zscore"].abs()
        df = df.sort_values("_sort_key", ascending=False).head(top_n)
        for _, row in df.iterrows():
            facts.append({
                "fact_type": "anomaly_var",
                "entities": [row["series"]],
                "period": row["date"],
                "value_summary": {"zscore": row["zscore"], "residual": row["residual"]},
                "confidence": min(abs(row["zscore"]) / 5.0, 1.0),
                "display": f"{row['series']} за {row['date']}: отклонение z={row['zscore']:.2f} "
                           f"(ожидалось иное с учётом связанных показателей: {row['cluster_members']})",
            })

    elif "forecast_low" in df.columns:
        # ── формат Chronos ──
        interval_width = (df["forecast_high"] - df["forecast_low"]).clip(lower=1e-9)
        df["_sort_key"] = (df["actual"] - df["forecast_median"]).abs() / interval_width
        df = df.sort_values("_sort_key", ascending=False).head(top_n)
        for _, row in df.iterrows():
            facts.append({
                "fact_type": "anomaly_chronos",
                "entities": [row["series"]],
                "period": row["date"],
                "value_summary": {
                    "actual": row["actual"], "forecast_low": row["forecast_low"],
                    "forecast_median": row["forecast_median"], "forecast_high": row["forecast_high"],
                },
                "confidence": min(float(row["_sort_key"]) / 3.0, 1.0),
                "display": f"{row['series']} за {row['date']}: факт {row['actual']:.1f}, "
                           f"ожидался диапазон [{row['forecast_low']:.1f}, {row['forecast_high']:.1f}] "
                           f"(группа: {row.get('cluster_members', '')})",
            })
    else:
        print(f"Предупреждение: не удалось распознать формат '{anomalies_path}' "
              f"(нет ни 'zscore', ни 'forecast_low').", file=sys.stderr)

    return facts


def build_facts_from_links(links_path: str, top_n: int, min_similarity: float):
    df = pd.read_csv(links_path, sep=";", encoding="utf-8-sig")
    df = df[df["similarity"] >= min_similarity].copy()
    df = df.sort_values("similarity", ascending=False).head(top_n)

    has_group = "group_a" in df.columns

    facts = []
    for _, row in df.iterrows():
        if has_group:
            a = f"{row['group_a']}: {row['metric_a']}" if row["group_a"] else row["metric_a"]
            b = f"{row['group_b']}: {row['metric_b']}" if row["group_b"] else row["metric_b"]
        else:
            a, b = row["metric_a"], row["metric_b"]

        facts.append({
            "fact_type": "link_semantic",
            "entities": [a, b],
            "period": None,
            "value_summary": {"similarity": row["similarity"]},
            "confidence": row["similarity"],
            "display": f"'{a}' и '{b}' семантически похожи (схожесть {row['similarity']:.2f}) — "
                       f"наблюдение, не доказанная причинно-следственная связь",
        })
    return facts


def assign_fact_ids(facts: list):
    for i, f in enumerate(facts, start=1):
        f["fact_id"] = f"f_{i:03d}"
    return facts


# ────────────────────────────────────────────────────────────────────────────
# 2. Построение промпта с жёстким контрактом на вывод
# ────────────────────────────────────────────────────────────────────────────

PROMPT_TEMPLATE = """Ты помощник-аналитик, который пишет краткий бриф на основе строго заданных фактов.

ПРАВИЛА (обязательны):
1. Используй ТОЛЬКО факты из списка ниже. Не добавляй никаких цифр, дат или названий, которых нет в списке.
2. Для каждого предложения бриф укажи, на каком факте (fact_id) оно основано.
3. Не пиши сами числа в тексте — просто опиши смысл словами, число будет подставлено автоматически.
4. Если факт — это "наблюдение" (semantic link), явно формулируй его как наблюдение, а не как причину.
5. Верни ТОЛЬКО валидный JSON как обычный текстовый (plain text) ответ:
   - без markdown-разметки и без блоков ```;
   - без пояснений, комментариев или заголовков до или после JSON;
   - первый символ твоего ответа должен быть "{{", последний — "}}";
   - без невидимых служебных символов в начале (например, BOM/zero-width space).
6. Этот ответ будет сохранён пользователем в файл response_brief.json — отвечай так,
   как будто ты формируешь содержимое именно этого файла, а не сообщение в чате.

Формат ответа:
{{
  "segments": [
    {{"fact_id": "f_001", "narrative": "связный текст на русском без чисел"}},
    ...
  ]
}}

Факты:
{facts_json}
"""


def build_prompt(facts: list) -> str:
    facts_for_prompt = [
        {"fact_id": f["fact_id"], "type": f["fact_type"], "entities": f["entities"], "period": f["period"]}
        for f in facts
    ]
    return PROMPT_TEMPLATE.format(facts_json=json.dumps(facts_for_prompt, ensure_ascii=False, indent=2))


# ────────────────────────────────────────────────────────────────────────────
# 3. Вызов LLM — ЗАГЛУШКА, замените на вызов вашей внутренней модели
# ────────────────────────────────────────────────────────────────────────────

def call_llm(prompt: str) -> str:
    """
    ЗАМЕНИТЕ ЭТУ ФУНКЦИЮ на реальный вызов вашей внутренней LLM.

    Типичный вид (если у вас OpenAI-совместимый эндпоинт, например через vLLM):

        import requests
        resp = requests.post(
            "http://ваш-внутренний-адрес/v1/chat/completions",
            json={
                "model": "ваша-модель",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.7,
            },
            timeout=60,
        )
        return resp.json()["choices"][0]["message"]["content"]

    Сейчас здесь — заглушка для теста без реальной модели.
    """
    raise NotImplementedError(
        "call_llm() — заглушка. Подставьте сюда вызов вашей внутренней LLM (см. комментарий в функции)."
    )


# ────────────────────────────────────────────────────────────────────────────
# 4. Валидация ответа — проверка, что все fact_id реальны
# ────────────────────────────────────────────────────────────────────────────

def validate_llm_output(raw_response: str, facts_by_id: dict):
    """Парсит JSON от LLM, отбрасывает сегменты со ссылкой на несуществующий факт.

    Возвращает (valid_segments, rejected_segments).
    """
    cleaned = re.sub(r"^```(json)?|```$", "", raw_response.strip(), flags=re.MULTILINE).strip()
    cleaned = cleaned.lstrip("\ufeff")  # BOM не убирается обычным .strip(), убираем явно
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise ValueError(f"LLM вернула невалидный JSON: {e}\nОтвет был:\n{raw_response}")

    valid, rejected = [], []
    for seg in data.get("segments", []):
        fid = seg.get("fact_id")
        if fid in facts_by_id:
            valid.append(seg)
        else:
            rejected.append(seg)
    return valid, rejected


# ────────────────────────────────────────────────────────────────────────────
# 5. Рендер финального текста — реальные цифры подставляет КОД, не LLM
# ────────────────────────────────────────────────────────────────────────────

def format_value(fact: dict) -> str:
    if fact["fact_type"] == "anomaly_var":
        return f"(z-score {fact['value_summary']['zscore']:.2f}, период {fact['period']})"
    if fact["fact_type"] == "anomaly_chronos":
        v = fact["value_summary"]
        return (f"(факт {v['actual']:.1f}, ожидался диапазон "
                f"[{v['forecast_low']:.1f}, {v['forecast_high']:.1f}], период {fact['period']})")
    if fact["fact_type"] == "link_semantic":
        return f"(схожесть {fact['value_summary']['similarity']:.2f})"
    return ""


def render_brief(valid_segments: list, facts_by_id: dict) -> str:
    lines = []
    for seg in valid_segments:
        fact = facts_by_id[seg["fact_id"]]
        narrative = seg.get("narrative", "").strip()
        lines.append(f"- {narrative} {format_value(fact)}")
    return "\n".join(lines)


# ────────────────────────────────────────────────────────────────────────────
# main
# ────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--anomalies", required=True, help="CSV из find_var_anomalies.py")
    parser.add_argument("--links", required=True, help="CSV из find_metric_links.py")
    parser.add_argument("--output", required=True, help="путь к итоговому .md брифу")
    parser.add_argument("--top-anomalies", type=int, default=5)
    parser.add_argument("--top-links", type=int, default=3)
    parser.add_argument("--min-similarity", type=float, default=0.75)
    parser.add_argument("--dry-run", action="store_true", help="не вызывать LLM, только показать промпт и факты")
    parser.add_argument("--save-prompt", default=None,
                         help="сохранить промпт в текстовый файл — чтобы скопировать его в чат LLM руками")
    parser.add_argument("--response-file", default=None,
                         help="путь к файлу, куда вы вставили ответ LLM (ручной режим, без API)")
    args = parser.parse_args()

    facts = []
    facts += build_facts_from_anomalies(args.anomalies, args.top_anomalies)
    facts += build_facts_from_links(args.links, args.top_links, args.min_similarity)
    facts = assign_fact_ids(facts)

    print(f"Собрано фактов: {len(facts)}", file=sys.stderr)
    for f in facts:
        print(f"  [{f['fact_id']}] {f['display']}", file=sys.stderr)

    if not facts:
        print("Нет фактов для брифа (нет аномалий/связей выше порогов).", file=sys.stderr)
        sys.exit(0)

    facts_by_id = {f["fact_id"]: f for f in facts}
    prompt = build_prompt(facts)

    if args.save_prompt:
        with open(args.save_prompt, "w", encoding="utf-8") as f:
            f.write(prompt)
        print(f"Промпт сохранён в '{args.save_prompt}' — откройте файл, скопируйте всё содержимое "
              f"и вставьте в чат вашей LLM.", file=sys.stderr)

    if args.dry_run:
        print("\n──── ПРОМПТ (dry-run, LLM не вызывается) ────\n", file=sys.stderr)
        print(prompt)
        return

    # ── Ручной режим: ответ LLM уже лежит в файле (вставили сами из чата) ──
    if args.response_file:
        raw_response = read_text_auto_encoding(args.response_file)
        print(f"Читаю ответ LLM из '{args.response_file}'...", file=sys.stderr)
    else:
        # ── Автоматический режим: вызов через API (нужно сначала реализовать call_llm) ──
        raw_response = call_llm(prompt)

    valid_segments, rejected = validate_llm_output(raw_response, facts_by_id)

    if rejected:
        print(f"ВНИМАНИЕ: отклонено {len(rejected)} сегментов со ссылкой на несуществующий факт "
              f"(возможная галлюцинация): {rejected}", file=sys.stderr)

    if not valid_segments:
        print("Ни один сегмент не прошёл валидацию — бриф не сформирован.", file=sys.stderr)
        sys.exit(1)

    brief_text = render_brief(valid_segments, facts_by_id)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"# Автоматический бриф\n\n{brief_text}\n")

    print(f"Готово. Бриф сохранён в '{args.output}' ({len(valid_segments)} из {len(facts)} фактов использовано).",
          file=sys.stderr)


if __name__ == "__main__":
    main()

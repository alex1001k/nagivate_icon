"""
Ищет КРУПНЫЕ ОТКЛОНЕНИЯ ФАКТА ОТ ПЛАНА за последние N периодов (по умолчанию 3).

В отличие от VAR/Chronos, этому методу НЕ нужна длинная история — он просто
сравнивает факт с планом на каждую из последних дат. Подходит именно для
случаев с малым числом периодов (месячные итоги, квартальные срезы и т.п.),
где статистические модели ненадёжны из-за нехватки данных.

Ожидаемый формат входных данных (длинный формат):
    unit_name (опционально); metric_name; d_date; fact_value; plan_value

Запуск:
    python find_plan_deviations.py --input facts.csv \\
        --metric-column pokaz_name --date-column date_ \\
        --value-column fact --plan-column plan \\
        --output plan_deviations.csv

Параметры:
    --input              CSV/Excel с фактами
    --sheet              лист Excel (не используется для CSV)
    --unit-column        (опционально) колонка юнита
    --metric-column      колонка с названием показателя
    --date-column        колонка с датой/периодом
    --value-column       колонка с фактическим значением
    --plan-column        колонка с плановым значением
    --recent-months      сколько последних периодов проверять (по умолчанию 3)
    --deviation-threshold относительное отклонение, начиная с которого считается
                          "крупным" (по умолчанию 0.1 = 10%)
    --output             путь к результирующему CSV
    --sep                разделитель CSV (по умолчанию автоопределение)
"""

import argparse
import os
import sys

import pandas as pd


def read_input_auto(path: str, sep, sheet=0):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xls"):
        return pd.read_excel(path, sheet_name=sheet)
    if sep:
        return pd.read_csv(path, sep=sep, encoding="utf-8-sig")
    for candidate in (";", ","):
        df = pd.read_csv(path, sep=candidate, encoding="utf-8-sig")
        if df.shape[1] > 1:
            return df
    return df


def classify_deviation(fact, plan, threshold):
    """Возвращает (deviation_abs, deviation_pct, status, is_large_deviation)."""
    if plan is None or pd.isna(plan) or plan == 0:
        return None, None, "нет плана", False
    if fact is None or pd.isna(fact):
        return None, None, "нет данных", False

    deviation_abs = fact - plan
    deviation_pct = deviation_abs / abs(plan)

    is_large = abs(deviation_pct) >= threshold
    if not is_large:
        status = "в пределах нормы"
    elif deviation_pct > 0:
        status = "крупное превышение плана"
    else:
        status = "крупный срыв плана"

    return round(deviation_abs, 4), round(deviation_pct, 4), status, is_large


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True)
    parser.add_argument("--sheet", default=0)
    parser.add_argument("--unit-column", default=None)
    parser.add_argument("--metric-column", default="metric_name")
    parser.add_argument("--date-column", default="d_date")
    parser.add_argument("--value-column", default="fact_value")
    parser.add_argument("--plan-column", required=True, help="колонка с плановым значением")
    parser.add_argument("--recent-months", type=int, default=3,
                         help="сколько последних периодов проверять (по умолчанию 3)")
    parser.add_argument("--deviation-threshold", type=float, default=0.1,
                         help="относительное отклонение, начиная с которого оно 'крупное' (по умолчанию 0.1)")
    parser.add_argument("--output", required=True)
    parser.add_argument("--sep", default=None)
    args = parser.parse_args()

    df = read_input_auto(args.input, args.sep, args.sheet)

    rename_map = {
        args.metric_column: "metric_name",
        args.date_column: "d_date",
        args.value_column: "fact_value",
        args.plan_column: "plan_value",
    }
    for user_col in rename_map:
        if user_col not in df.columns:
            print(f"Ошибка: колонки '{user_col}' нет в файле. Доступные: {list(df.columns)}", file=sys.stderr)
            sys.exit(1)
    df = df.rename(columns=rename_map)

    if args.unit_column:
        if args.unit_column not in df.columns:
            print(f"Ошибка: колонки '{args.unit_column}' нет в файле.", file=sys.stderr)
            sys.exit(1)
        df = df.rename(columns={args.unit_column: "unit_name"})
    else:
        df["unit_name"] = "_all_"

    df["metric_name"] = df["metric_name"].astype(str).str.strip()
    df["unit_name"] = df["unit_name"].astype(str).str.strip()
    df["d_date"] = df["d_date"].astype(str).str.strip()
    df["fact_value"] = pd.to_numeric(df["fact_value"], errors="coerce")
    df["plan_value"] = pd.to_numeric(df["plan_value"], errors="coerce")

    results = []
    unique_series = df[["unit_name", "metric_name"]].drop_duplicates().values.tolist()
    print(f"Всего рядов для проверки: {len(unique_series)}", file=sys.stderr)

    for unit, metric in unique_series:
        sub = df[(df["unit_name"] == unit) & (df["metric_name"] == metric)]
        sub = sub.groupby("d_date")[["fact_value", "plan_value"]].sum().sort_index()

        # берём только последние N периодов
        recent = sub.tail(args.recent_months)
        label = f"{unit}:{metric}" if unit != "_all_" else metric

        for date, row in recent.iterrows():
            dev_abs, dev_pct, status, is_large = classify_deviation(
                row["fact_value"], row["plan_value"], args.deviation_threshold
            )
            results.append({
                "unit_name": unit, "metric_name": metric, "series": label, "date": date,
                "fact_value": row["fact_value"], "plan_value": row["plan_value"],
                "deviation_abs": dev_abs, "deviation_pct": dev_pct,
                "status": status, "is_large_deviation": is_large,
            })

    if not results:
        print("Не найдено ни одной строки для проверки.", file=sys.stderr)
        sys.exit(1)

    result_df = pd.DataFrame(results)
    result_df = result_df.sort_values(
        "deviation_pct", key=lambda s: s.abs(), ascending=False, na_position="last"
    )
    result_df.to_csv(args.output, sep=";", index=False, encoding="utf-8-sig")

    n_large = int(result_df["is_large_deviation"].sum())
    print(f"Готово. Крупных отклонений: {n_large} из {len(result_df)} проверенных строк. "
          f"Результат: '{args.output}'.", file=sys.stderr)


if __name__ == "__main__":
    main()

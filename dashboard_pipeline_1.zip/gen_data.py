\
# -*- coding: utf-8 -*-
"""
Синтетика для мокапа дэшборда: две таблицы (факты + справочник показателей),
расчёт отклонений/инсайтов и генерация текстовых брифов.
"""
import numpy as np
import pandas as pd
import json
import random

random.seed(42)
np.random.seed(42)

# ---------------------------------------------------------------------------
# 1. Каталог показателей
# ---------------------------------------------------------------------------

SCREENS = ['Онлайн', 'Инвестиции', 'Кидс', 'Цифровой ассистент']
SCREEN_CODE = {'Онлайн': 'ONL', 'Инвестиции': 'INV', 'Кидс': 'KIDS', 'Цифровой ассистент': 'ASSIST'}

# (категория, название, юнит, направление 'up'|'down' -- какое направление "хорошо")
BASE_CATALOG = [
    ('Клиентские', 'MAU', 'тыс.', 'up', 3200, 0.012),
    ('Клиентские', 'DAU', 'тыс.', 'up', 620, 0.015),
    ('Клиентские', 'Количество клиентов', 'тыс.', 'up', 1450, 0.010),
    ('Финансовые', 'Доля продаж', '%', 'up', 18.5, 0.006),
    ('Финансовые', 'Рекламная выручка', 'млн руб', 'up', 42.0, 0.018),
    ('Вовлечённость', 'Кол-во сообщений на клиента', 'шт', 'up', 6.4, 0.008),
    ('Вовлечённость', 'Доля возвратов', '%', 'down', 4.1, 0.004),
    ('Удовлетворённость', 'Доля обращений', '%', 'down', 7.8, 0.005),
    ('Удовлетворённость', 'Тупиковые ответы', '%', 'down', 12.3, 0.006),
]

NAME_CODE = {
    'MAU': 'MAU', 'DAU': 'DAU', 'Количество клиентов': 'CLIENTS',
    'Доля продаж': 'SALES_SHARE', 'Рекламная выручка': 'AD_REV',
    'Кол-во сообщений на клиента': 'MSG_PER_CLIENT', 'Доля возвратов': 'RETURN_RATE',
    'Доля обращений': 'APPEAL_RATE', 'Тупиковые ответы': 'DEADEND_RATE',
}

EXCLUDE = {
    'Кидс': {'Рекламная выручка'},
    'Цифровой ассистент': {'Рекламная выручка', 'Доля продаж'},
}

IMPORTANT_SET = {'MAU', 'Количество клиентов', 'Доля продаж', 'Доля возвратов'}
NO_TARGET_SET = {'Рекламная выручка', 'Кол-во сообщений на клиента'}

# зависимый показатель -> список ЕГО драйверов (может быть 0, 1 или несколько --
# это не строгая цепочка, а граф: у показателя бывает несколько драйверов сразу,
# и один драйвер может питать несколько зависимых показателей)
DRIVERS_OF = {
    'MAU': ['DAU'],
    'Количество клиентов': ['MAU'],
    'Доля продаж': ['Количество клиентов', 'Доля возвратов'],
    'Доля обращений': ['Тупиковые ответы', 'Кол-во сообщений на клиента'],
    'Доля возвратов': ['Доля обращений'],
}

SCREEN_SCALE = {'Онлайн': 1.0, 'Инвестиции': 0.55, 'Кидс': 0.30, 'Цифровой ассистент': 0.42}

# ---------------------------------------------------------------------------
# 2. Справочник показателей (dim)
# ---------------------------------------------------------------------------

dim_rows = []
id_by_screen_name = {}

for screen in SCREENS:
    for category, name, unit, direction, base, trend in BASE_CATALOG:
        if name in EXCLUDE.get(screen, set()):
            continue
        pid = f"{SCREEN_CODE[screen]}_{NAME_CODE[name]}"
        id_by_screen_name[(screen, name)] = pid
        dim_rows.append({
            'id_pokaz': pid,
            'pokaz_name': name,
            'screen': screen,
            'category': category,
            'unit': unit,
            'direction': direction,
            'is_important': name in IMPORTANT_SET,
            'has_target': name not in NO_TARGET_SET,
            'base': base * SCREEN_SCALE[screen],
            'trend': trend,
            'driver_names': DRIVERS_OF.get(name, []),
        })

# резолвим связи драйверов теперь, когда все id по экрану известны -- каждая
# связь "показатель <- драйвер" отдельной строкой в отдельной таблице (многие-ко-многим:
# у показателя может быть несколько драйверов, и один драйвер может кормить несколько показателей)
driver_link_rows = []
for row in dim_rows:
    for dname in row['driver_names']:
        if (row['screen'], dname) in id_by_screen_name:
            driver_link_rows.append({
                'id_pokaz': row['id_pokaz'],
                'driver_id': id_by_screen_name[(row['screen'], dname)],
            })
    del row['driver_names']

dim_df = pd.DataFrame(dim_rows)
driver_links_df = pd.DataFrame(driver_link_rows)

# ---------------------------------------------------------------------------
# 3. Временной ряд фактов/планов/прогнозов
# ---------------------------------------------------------------------------

MONTHS = pd.date_range('2025-04-01', '2026-07-01', freq='MS')
N = len(MONTHS)
LAST_IDX = N - 1  # июль 2026 -- текущий незакрытый месяц

fact_rows = []
anomalies = {}  # (id_pokaz, date_str) -> relative magnitude (для последующего использования в отклонениях как "инжект")
target_by_id = {}  # стратегическая цель показателя (отдельно от месячного плана)

for row in dim_rows:
    pid = row['id_pokaz']
    base = row['base']
    trend = row['trend']

    # лаг отчётности: у финансовых метрик и рекламной выручки данные обычно приходят позже
    if row['category'] == 'Финансовые':
        lag_months = 2
    else:
        lag_months = 1 if random.random() < 0.35 else 0
    # текущий месяц всегда прогноз (месяц не закрыт)
    lag_months = max(lag_months, 1)

    # базовая траектория
    t = np.arange(N)
    seasonal = 0.03 * base * np.sin(2 * np.pi * t / 12 + hash(pid) % 7)
    noise = np.random.normal(0, 0.02 * base, N)
    true_val = base * (1 + trend * t) + seasonal + noise

    # стратегическая цель -- отдельно от месячного плана: амбициознее, фиксирована на
    # горизонт всего периода (не пересчитывается каждый месяц)
    if row['has_target']:
        stretch = 1.06 if row['direction'] == 'up' else 0.94
        target_by_id[pid] = round(float(true_val[-1] * stretch), 2)
    else:
        target_by_id[pid] = None

    # инжектим аномалии в ~15% месяцев (не в первые 2, чтобы был референс для z-score)
    anomaly_mask = np.zeros(N, dtype=bool)
    for i in range(2, N):
        if random.random() < 0.15:
            anomaly_mask[i] = True

    fact_vals = true_val.copy()
    for i in range(N):
        if anomaly_mask[i]:
            mag = random.uniform(0.15, 0.42) * random.choice([-1, 1])
            fact_vals[i] = true_val[i] * (1 + mag)
            anomalies[(pid, MONTHS[i].strftime('%Y-%m-%d'))] = mag

    # план -- на базе "чистой" траектории с небольшим управленческим приростом
    plan_vals = true_val * (1 + 0.04 + np.random.normal(0, 0.01, N))

    for i in range(N):
        date_str = MONTHS[i].strftime('%Y-%m-%d')
        is_prognoz = i >= (LAST_IDX - lag_months + 1)

        # прогноз есть не всегда: часть непокрытых месяцев не имеет даже
        # предварительной оценки -- строки по ним просто отсутствуют
        if is_prognoz and random.random() < 0.22:
            continue

        fact = round(float(fact_vals[i]), 2)

        if row['has_target']:
            # план не всегда есть: для текущего месяца -- 50/50, для истории -- изредка пропуски
            if i == LAST_IDX and random.random() < 0.5:
                plan = None
            elif random.random() < 0.05:
                plan = None
            else:
                plan = round(float(plan_vals[i]), 2)
        else:
            plan = None

        fact_rows.append({
            'id_pokaz': pid,
            'pokaz_name': row['pokaz_name'],
            'date_': date_str,
            'fact': fact,
            'plan': plan,
            'prognoz_flg': int(is_prognoz),
        })

fact_df = pd.DataFrame(fact_rows)
dim_df['target_value'] = dim_df['id_pokaz'].map(target_by_id)

# ---------------------------------------------------------------------------
# 4. Сохраняем исходные таблицы как их пришлёт заказчик
# ---------------------------------------------------------------------------

fact_df.to_csv('fact_pokazateli.csv', index=False, encoding='utf-8-sig')
dim_export = dim_df.drop(columns=['base', 'trend'])
dim_export.to_csv('dim_pokazateli.csv', index=False, encoding='utf-8-sig')
driver_links_df.to_csv('driver_links.csv', index=False, encoding='utf-8-sig')

print('fact rows:', len(fact_df), '| dim rows:', len(dim_df), '| driver links:', len(driver_links_df))
print(fact_df.head(8).to_string())
print(dim_export.head(8).to_string())
print(driver_links_df.head(10).to_string())
links_per_metric = driver_links_df.groupby('id_pokaz').size()
print('metrics with >1 driver:', (links_per_metric > 1).sum())

# -*- coding: utf-8 -*-
"""
Собирает dashboard_final.html из шаблона dashboard.html + данных bundle.json +
скрипта dashboard.js. Запускать после compute_insights.py (он готовит bundle.json).
"""
data = open('bundle.json', encoding='utf-8').read()
template = open('dashboard.html', encoding='utf-8').read()
js = open('dashboard.js', encoding='utf-8').read()

out = template.replace('__DASHBOARD_DATA__', data).replace('__DASHBOARD_JS__', js)

open('dashboard_final.html', 'w', encoding='utf-8').write(out)
print('dashboard_final.html собран')

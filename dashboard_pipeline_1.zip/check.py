import asyncio, pathlib, sys
from playwright.async_api import async_playwright

PATH = pathlib.Path('/home/claude/dash_mockup/dashboard_final.html').resolve()

async def main():
    errors = []
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path='/opt/pw-browsers/chromium', args=['--no-sandbox'])
        page = await browser.new_page(viewport={'width':1600,'height':1000})
        page.on('console', lambda msg: errors.append(msg.text) if msg.type == 'error' else None)
        page.on('pageerror', lambda exc: errors.append('PAGEERROR: ' + str(exc)))
        await page.goto('file://' + str(PATH))
        await page.wait_for_timeout(500)

        # basic sanity checks
        rows = await page.locator('tr.metric-row').count()
        groups = await page.locator('tr.group-row').count()
        print('metric rows:', rows, '| group rows:', groups)

        await page.screenshot(path='shot_1_initial.png', full_page=True)

        # click category grouping toggle
        await page.click('button[data-mode="category"]')
        await page.wait_for_timeout(200)
        await page.screenshot(path='shot_2_category_group.png', full_page=True)

        # switch back, click important filter
        await page.click('button[data-mode="screen"]')
        await page.click('#filterImportant')
        await page.wait_for_timeout(200)
        rows_important = await page.locator('tr.metric-row').count()
        print('rows after important filter:', rows_important)
        await page.screenshot(path='shot_3_important_filter.png', full_page=True)
        await page.click('#filterImportant')  # unclick

        # click a table row to test interactivity
        await page.click('tr.metric-row >> nth=5')
        await page.wait_for_timeout(200)
        await page.screenshot(path='shot_4_row_selected.png', full_page=True)

        # test brief pager next button if present
        next_btn = page.locator('#briefNext')
        if await next_btn.count() and not await next_btn.is_disabled():
            await next_btn.click()
            await page.wait_for_timeout(150)
            await page.screenshot(path='shot_5_brief_paged.png', full_page=True)

        # collapse a group
        await page.click('tr.group-row >> nth=0')
        await page.wait_for_timeout(150)
        await page.screenshot(path='shot_6_group_collapsed.png', full_page=True)

        await browser.close()

    print('CONSOLE ERRORS:', len(errors))
    for e in errors[:30]:
        print(' -', e)

asyncio.run(main())

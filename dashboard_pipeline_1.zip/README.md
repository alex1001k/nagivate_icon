# Дашборд продуктовых показателей — мокап

## Что тут есть

Пайплайн из трёх шагов: синтетика → расчёт отклонений/брифов → сборка HTML.

| Файл | Что делает |
|---|---|
| `gen_data.py` | Генерирует синтетические `fact_pokazateli.csv`, `dim_pokazateli.csv`, `driver_links.csv`. Когда появятся реальные выгрузки — этот шаг просто пропускаете, кладёте свои CSV с такой же структурой рядом и идёте сразу к следующему шагу. |
| `compute_insights.py` | Читает `fact_pokazateli.csv` + `dim_pokazateli.csv` + `driver_links.csv`, считает отклонения по 7 статистическим правилам, генерирует тексты брифов, пишет `briefs_pokazateli.csv` (для BI) и `bundle.json` (данные для HTML-мокапа). |
| `build.py` | Склеивает `dashboard.html` (шаблон/стили) + `bundle.json` (данные) + `dashboard.js` (логика) в один самодостаточный `dashboard_final.html`. |
| `dashboard.html` / `dashboard.js` | Шаблон и вся клиентская логика дашборда — их редактируете, когда нужно поменять вёрстку/поведение. |
| `check.py` | Опциональный Playwright-скрипт для авто-проверки (0 ошибок в консоли + скриншоты). Не обязателен для работы, только для тестирования при разработке. |

## Установка на рабочем компьютере

Нужен Python 3.9+.

```bash
python3 -m venv venv
source venv/bin/activate        # на Windows: venv\Scripts\activate
pip install -r requirements.txt
```

`check.py` (опционально, для автотестов) дополнительно требует `playwright`:
```bash
pip install playwright
playwright install chromium
```

## Как запускать

Из папки с файлами, по порядку:

```bash
python3 gen_data.py          # синтетика -- пропустить, когда будете использовать реальные CSV
python3 compute_insights.py  # брифы + bundle.json
python3 build.py             # dashboard_final.html
```

Открыть `dashboard_final.html` в браузере — это готовый интерактивный мокап, файл ничего не подгружает извне, можно просто переслать/открыть локально.

## Переход на реальные данные

Когда будет доступ к настоящей выгрузке — кладёте `fact_pokazateli.csv` и `dim_pokazateli.csv` (и `driver_links.csv`, если он у вас появится) рядом со скриптами, с той же структурой колонок, что и в текущих синтетических файлах, и запускаете сразу `compute_insights.py` → `build.py`, без `gen_data.py`.

Структура таблиц:

- **`fact_pokazateli.csv`**: `id_pokaz, pokaz_name, date_, fact, plan, prognoz_flg`
- **`dim_pokazateli.csv`**: `id_pokaz, pokaz_name, screen, category, unit, direction, is_important, has_target, target_value` (метаданные показателя; `driver_ids` в bundle считается из `driver_links.csv`, отдельной колонки `parent_id` больше нет)
- **`driver_links.csv`**: `id_pokaz, driver_id` — связь многие-ко-многим, у показателя может быть 0/1/несколько драйверов
- **`briefs_pokazateli.csv`**: результат, отдельно грузится в BI

## Настройки/пороги

В начале `compute_insights.py`:

```python
PLAN_TH, MOM_TH, Z_TH, YOY_TH = 1.0, 1.0, 1.8, 15.0
STREAK_TH, STREAK_NOISE, VOL_RATIO_TH, VOL_FLOOR = 3, 2.0, 1.8, 0.03
PLAN_BAND, MOM_BAND = 4.0, 1.5
```

Меняете пороги здесь — ничего больше трогать не нужно, они используются и в тексте брифов, и в панели методологии на дашборде.

"""
Тестовый скрипт для проверки подключения к вашей внутренней LLM через API,
прежде чем гонять весь пайплайн.

Запуск:
    python test_llm_api.py --api-base http://34.56.56.65:8394/v1 --api-key ВАШ_КЛЮЧ

Если у вашей модели другое имя (не "default") — добавьте:
    --model-name имя_вашей_модели
"""

import argparse
import sys

import requests


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--api-base", required=True, help="например http://34.56.56.65:8394/v1")
    parser.add_argument("--api-key", default=None, help="API-ключ/токен, если требуется")
    parser.add_argument("--model-name", default="default")
    parser.add_argument("--timeout", type=int, default=30)
    args = parser.parse_args()

    url = args.api_base.rstrip("/")
    if not url.endswith("/chat/completions"):
        url += "/chat/completions"

    headers = {"Content-Type": "application/json"}
    if args.api_key:
        headers["Authorization"] = f"Bearer {args.api_key}"

    payload = {
        "model": args.model_name,
        "messages": [{"role": "user", "content": "Привет, ответь одним словом: работает?"}],
        "temperature": 0.3,
    }

    print(f"Отправляю запрос на: {url}", file=sys.stderr)
    print(f"Заголовки: {list(headers.keys())} (значения скрыты)", file=sys.stderr)
    print(f"Тело запроса: {payload}\n", file=sys.stderr)

    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=args.timeout)
    except requests.exceptions.ConnectionError as e:
        print(f"ОШИБКА СОЕДИНЕНИЯ: не удалось подключиться к '{url}'.\n"
              f"Проверьте адрес и доступность сервера из этой сети.\nПодробности: {e}", file=sys.stderr)
        sys.exit(1)
    except requests.exceptions.Timeout:
        print(f"ОШИБКА: сервер не ответил за {args.timeout} секунд.", file=sys.stderr)
        sys.exit(1)

    print(f"Код ответа: {resp.status_code}", file=sys.stderr)
    print(f"Текст ответа (первые 2000 символов):\n{resp.text[:2000]}\n", file=sys.stderr)

    if resp.status_code == 200:
        try:
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            print("УСПЕХ — формат ответа стандартный (OpenAI-совместимый).", file=sys.stderr)
            print(f"Ответ модели: {content}", file=sys.stderr)
            print("\nМожно использовать --api-base с этим адресом в profile_columns.py, "
                  "generate_brief.py и run_pipeline.py как есть.", file=sys.stderr)
        except (KeyError, IndexError, ValueError) as e:
            print(f"Код 200, но структура JSON НЕ стандартная (нет choices/message/content).\n"
                  f"Ошибка разбора: {e}\n"
                  f"Пришлите весь текст ответа выше — нужно будет поправить код разбора под "
                  f"вашу структуру.", file=sys.stderr)
    elif resp.status_code in (401, 403):
        print("Ошибка авторизации — проверьте API-ключ или способ его передачи "
              "(возможно, нужен другой заголовок, не 'Authorization: Bearer').", file=sys.stderr)
    elif resp.status_code == 404:
        print("Путь не найден — возможно, эндпоинт называется иначе, чем '/chat/completions'. "
              "Уточните у коллег точный путь.", file=sys.stderr)
    else:
        print(f"Неожиданный код ответа {resp.status_code} — пришлите текст ответа выше.",
              file=sys.stderr)


if __name__ == "__main__":
    main()

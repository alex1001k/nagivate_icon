"""
Находит структурные связи вида "показатель на уровне компании/итого = сумма
того же показателя по юнитам" — проверяется не похожестью названий, а прямым
арифметическим совпадением сумм на каждую дату.

Это ДРУГОЙ тип связи, чем в find_metric_links.py (там — семантическая похожесть
названий внутри юнита). Здесь — наоборот: связь обязана пересекать границы
юнитов, потому что показатель "Компании" по определению состоит из юнитов.

Ожидаемый формат входного CSV (канонические факты, как в вашем my_report.py):
    unit_name;metric_name;d_date;fact_value

Запуск (простой случай — названия показателя совпадают на итоговом
и юнитовом уровне, например "Маржа" и там, и там):
    python find_aggregation_links.py --input facts.csv --total-units "Компания,Итого" --output agg_links.csv

Запуск с алиасами (если итоговый показатель называется иначе, чем на уровне
юнита — например "Общая маржа" на уровне компании и "Маржа" на уровне юнита):
    python find_aggregation_links.py --input facts.csv --total-units "Компания" \
        --alias-file aliases.csv --output agg_links.csv

Файл aliases.csv (если используется) должен иметь колонки:
    total_metric;unit_metric
    Общая маржа;Маржа

Параметры:
    --input           путь к CSV с фактами (unit_name, metric_name, d_date, fact_value)
    --total-units     через запятую — названия юнитов, представляющих "итого/компанию"
    --alias-file      (опционально) CSV с парами total_metric;unit_metric для случаев,
                       когда название на итоговом уровне отличается от юнитового
    --output          путь к результирующему CSV со связями
    --tolerance       относительный допуск при сравнении сумм (по умолчанию 0.02 = 2%)
    --min-match-rate  минимальная доля периодов, где сумма сошлась, чтобы считать
                       связь подтверждённой (по умолчанию 0.8 = 80% периодов)
    --min-periods     минимальное число периодов для проверки, иначе совпадение
                       может быть случайным (по умолчанию 3)
    --sep             разделитель входного CSV (по умолчанию автоопределение)
"""

import argparse
import csv
import sys

import numpy as np
import pandas as pd


def read_csv_auto_sep(path: str, sep: str | None):
    if sep:
        return pd.read_csv(path, sep=sep, encoding="utf-8-sig")
    for candidate in (";", ","):
        df = pd.read_csv(path, sep=candidate, encoding="utf-8-sig")
        if df.shape[1] > 1:
            return df
    return df


def check_aggregation(total_series: pd.Series, parts_series: pd.Series, tolerance: float):
    """Сравнивает две серии (по датам) с относительным допуском.

    Возвращает (n_common_periods, n_matched, avg_relative_diff).
    """
    common_dates = sorted(set(total_series.index) & set(parts_series.index))
    if not common_dates:
        return 0, 0, None

    diffs = []
    matched = 0
    for d in common_dates:
        t = total_series[d]
        p = parts_series[d]
        denom = max(abs(t), 1e-9)
        rel_diff = abs(t - p) / denom
        diffs.append(rel_diff)
        if rel_diff <= tolerance:
            matched += 1

    return len(common_dates), matched, float(np.mean(diffs))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True, help="CSV с фактами: unit_name, metric_name, d_date, fact_value")
    parser.add_argument("--total-units", required=True,
                         help="через запятую: названия юнитов, представляющих итого/компанию")
    parser.add_argument("--alias-file", default=None,
                         help="CSV с парами total_metric;unit_metric для несовпадающих названий")
    parser.add_argument("--output", required=True, help="путь к результирующему CSV")
    parser.add_argument("--tolerance", type=float, default=0.02, help="относительный допуск (по умолчанию 0.02)")
    parser.add_argument("--min-match-rate", type=float, default=0.8,
                         help="минимальная доля совпавших периодов (по умолчанию 0.8)")
    parser.add_argument("--min-periods", type=int, default=3,
                         help="минимальное число периодов для проверки (по умолчанию 3)")
    parser.add_argument("--sep", default=None, help="разделитель входного CSV")
    args = parser.parse_args()

    df = read_csv_auto_sep(args.input, args.sep)
    required_cols = {"unit_name", "metric_name", "d_date", "fact_value"}
    missing = required_cols - set(df.columns)
    if missing:
        print(f"Ошибка: в файле не хватает колонок: {missing}. Есть: {list(df.columns)}", file=sys.stderr)
        sys.exit(1)

    df["unit_name"] = df["unit_name"].astype(str).str.strip()
    df["metric_name"] = df["metric_name"].astype(str).str.strip()
    df["d_date"] = df["d_date"].astype(str).str.strip()
    df["fact_value"] = pd.to_numeric(df["fact_value"], errors="coerce")

    total_units = {u.strip() for u in args.total_units.split(",") if u.strip()}
    totals_df = df[df["unit_name"].isin(total_units)]
    parts_df = df[~df["unit_name"].isin(total_units)]

    if totals_df.empty:
        print(f"Ошибка: не найдено ни одной строки с unit_name из {total_units}. "
              f"Проверьте написание (регистр, пробелы).", file=sys.stderr)
        sys.exit(1)

    # ── Собираем пары (total_metric, unit_metric) для проверки ──
    # по умолчанию: одинаковые названия на итоговом и юнитовом уровне
    same_name_metrics = sorted(set(totals_df["metric_name"]) & set(parts_df["metric_name"]))
    metric_pairs = [(m, m) for m in same_name_metrics]

    # плюс алиасы из файла, если указан
    if args.alias_file:
        alias_df = read_csv_auto_sep(args.alias_file, None)
        for _, row in alias_df.iterrows():
            metric_pairs.append((str(row["total_metric"]).strip(), str(row["unit_metric"]).strip()))

    metric_pairs = list(dict.fromkeys(metric_pairs))  # убираем дубли, сохраняя порядок
    print(f"Проверяю {len(metric_pairs)} пар показателей (итог ↔ юниты)...", file=sys.stderr)

    results = []
    for total_metric, unit_metric in metric_pairs:
        total_rows = totals_df[totals_df["metric_name"] == total_metric]
        part_rows = parts_df[parts_df["metric_name"] == unit_metric]

        if total_rows.empty or part_rows.empty:
            continue

        total_series = total_rows.groupby("d_date")["fact_value"].sum()
        parts_series = part_rows.groupby("d_date")["fact_value"].sum()

        n_common, n_matched, avg_diff = check_aggregation(total_series, parts_series, args.tolerance)
        if n_common < args.min_periods:
            continue

        match_rate = n_matched / n_common
        contributing_units = sorted(part_rows["unit_name"].unique().tolist())

        results.append({
            "total_metric": total_metric,
            "unit_metric": unit_metric,
            "n_periods_checked": n_common,
            "n_periods_matched": n_matched,
            "match_rate": round(match_rate, 3),
            "avg_relative_diff": round(avg_diff, 4) if avg_diff is not None else None,
            "structural_link": match_rate >= args.min_match_rate,
            "contributing_units": ", ".join(contributing_units),
        })

    if not results:
        print("Не найдено ни одной пары показателей с достаточным числом общих периодов "
              f"(минимум {args.min_periods}). Проверьте --total-units и формат d_date.", file=sys.stderr)

    results.sort(key=lambda r: (-r["structural_link"], -r["match_rate"]))

    with open(args.output, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "total_metric", "unit_metric", "n_periods_checked", "n_periods_matched",
            "match_rate", "avg_relative_diff", "structural_link", "contributing_units",
        ], delimiter=";")
        writer.writeheader()
        writer.writerows(results)

    n_confirmed = sum(1 for r in results if r["structural_link"])
    print(f"Готово. Проверено пар: {len(results)}, подтверждено как структурная связь: {n_confirmed}. "
          f"Результат сохранён в '{args.output}'.", file=sys.stderr)


if __name__ == "__main__":
    main()

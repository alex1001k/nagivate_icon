"""
Оркестратор: указываете ОДИН источник данных — дальше вся цепочка (роли колонок,
связи, аномалии, бриф) отрабатывает автоматически. Все промежуточные и итоговые
файлы автоматически называются по имени источника и складываются в отдельную
папку для этого источника — при работе с несколькими источниками их результаты
никогда не перемешаются и не перезапишут друг друга.

ГЛАВНАЯ ПЕРЕМЕННАЯ — ИСТОЧНИК:
    --input   Путь к файлу-источнику (CSV/Excel). Именно отсюда берётся имя,
              которое подставляется во ВСЕ последующие файлы результатов
              и в имя папки. Сейчас поддерживаются файлы CSV/Excel;
              при подключении других источников (БД, API, датафрейм в памяти)
              этот параметр — единственное место в пайплайне, которое нужно
              будет расширить, чтобы завести новый тип источника.

СТРУКТУРА РЕЗУЛЬТАТОВ (пример для --input fact_pokazateli.csv):
    <work-dir>/fact_pokazateli/
        fact_pokazateli_column_roles.csv
        fact_pokazateli_links.csv
        fact_pokazateli_anomalies.csv
        fact_pokazateli_prompt_for_chat.txt      (только в ручном режиме)
        fact_pokazateli_brief.md

ЗАПУСК — если у вас уже есть рабочий --api-base (полностью автоматически):
    python run_pipeline.py --input fact_pokazateli.csv \\
        --api-base http://34.56.56.65:8394/v1 --api-key ВАШ_КЛЮЧ

Это само, по цепочке:
  1) если ролей колонок для этого источника ещё нет — вызовет profile_columns.py
  2) find_metric_links.py     -> ..._links.csv
  3) find_chronos/var_anomalies.py -> ..._anomalies.csv
  4) generate_brief.py        -> ..._brief.md

ЗАПУСК — без API (ручной копипаст на двух шагах, как раньше):
    python run_pipeline.py --input fact_pokazateli.csv

Если ролей колонок для этого источника ещё нет — скрипт остановится и покажет
точные команды для разового шага profile_columns.py. После того как
column_roles.csv появится — запустите ту же команду ещё раз, дальше пайплайн
дойдёт до сборки промпта для брифа и покажет команды для последнего ручного шага.

Параметры:
    --input           источник данных (CSV/Excel) — главная переменная пайплайна
    --work-dir        базовая папка, внутри неё создаётся подпапка по имени источника
                       (по умолчанию "./runs")
    --column-roles    (опционально) свой путь к файлу ролей колонок вместо автоматического
    --anomaly-method  chronos | var (по умолчанию chronos)
    --embed-model     путь/имя модели эмбеддингов
                       (по умолчанию /home/datalab/nfs/embed/bge-m3-local)
    --chronos-model   путь/имя модели Chronos
                       (по умолчанию /home/datalab/nfs/chronos/autogluon_chronos-2)
    --context-length  сколько предыдущих периодов видит Chronos (по умолчанию 6)
    --check-last-n    проверять только последние N периодов (по умолчанию 3)
    --api-base        адрес API вашей LLM — включает полностью автоматический режим
    --api-key         API-ключ/токен, если требуется
    --model-name      имя модели для поля 'model' в запросе (по умолчанию "default")
    --sep             разделитель CSV источника (по умолчанию автоопределение)
"""

import argparse
import os
import re
import subprocess
import sys

import pandas as pd


def sanitize_name(name: str) -> str:
    """Превращает имя источника в безопасную для файловой системы строку
    (без пробелов, слэшей, кириллица разрешена)."""
    name = re.sub(r"[^\w\-.]+", "_", name, flags=re.UNICODE)
    return name.strip("_") or "source"


def load_column_roles(path: str) -> dict:
    df = pd.read_csv(path, sep=";", encoding="utf-8-sig")
    roles = {}
    for _, row in df.iterrows():
        role = row["role"]
        if role not in roles:
            roles[role] = row["column"]
    return roles


def run_step(description: str, cmd: list):
    print(f"\n{'='*70}\n{description}\n{'='*70}", file=sys.stderr)
    print("Команда:", " ".join(cmd), file=sys.stderr)
    result = subprocess.run(cmd, text=True)
    if result.returncode != 0:
        print(f"\nОШИБКА: шаг '{description}' завершился с кодом {result.returncode}. "
              f"Пайплайн остановлен.", file=sys.stderr)
        sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True, help="источник данных (CSV/Excel) — главная переменная")
    parser.add_argument("--work-dir", default="./runs",
                         help="базовая папка, внутри создаётся подпапка по имени источника")
    parser.add_argument("--column-roles", default=None,
                         help="свой путь к файлу ролей колонок вместо автоматического")
    parser.add_argument("--anomaly-method", choices=["chronos", "var"], default="chronos")
    parser.add_argument("--embed-model", default="/home/datalab/nfs/embed/bge-m3-local")
    parser.add_argument("--chronos-model", default="/home/datalab/nfs/chronos/autogluon_chronos-2")
    parser.add_argument("--context-length", type=int, default=6)
    parser.add_argument("--check-last-n", type=int, default=3)
    parser.add_argument("--api-base", default=None)
    parser.add_argument("--api-key", default=None)
    parser.add_argument("--model-name", default="default")
    parser.add_argument("--sep", default=None)
    args = parser.parse_args()

    # ── Главная переменная источника: всё дальнейшее именование строится от неё ──
    source_name = sanitize_name(os.path.splitext(os.path.basename(args.input))[0])
    output_dir = os.path.join(args.work_dir, source_name)
    os.makedirs(output_dir, exist_ok=True)
    print(f"Источник: '{args.input}' -> имя для файлов: '{source_name}' -> папка: '{output_dir}'",
          file=sys.stderr)

    def out(suffix):
        return os.path.join(output_dir, f"{source_name}_{suffix}")

    column_roles_path = args.column_roles or out("column_roles.csv")
    links_path = out("links.csv")
    anomalies_path = out("anomalies.csv")
    prompt_path = out("prompt_for_chat.txt")
    brief_path = out("brief.md")
    profile_prompt_path = out("prompt_profile.txt")
    response_profile_path = out("response_profile.txt")
    response_brief_path = out("response_brief.txt")

    py = sys.executable

    # ── Роли колонок: свои, уже готовые, или создать (авто через API / вручную) ──
    if not os.path.exists(column_roles_path):
        if args.api_base:
            cmd = [py, "profile_columns.py", "--input", args.input, "--output", column_roles_path,
                   "--api-base", args.api_base, "--model-name", args.model_name]
            if args.api_key:
                cmd += ["--api-key", args.api_key]
            if args.sep:
                cmd += ["--sep", args.sep]
            run_step(f"Шаг 0: определение ролей колонок для '{source_name}' (profile_columns.py, через API)", cmd)
        else:
            print(f"Файл ролей колонок '{column_roles_path}' ещё не создан для источника '{source_name}'.\n\n"
                  f"Выполните разово (ручной режим, через чат LLM):\n"
                  f"  python profile_columns.py --input {args.input} --save-prompt {profile_prompt_path} --dry-run\n"
                  f"  (скопируйте промпт в чат LLM, ответ сохраните в {response_profile_path})\n"
                  f"  python profile_columns.py --input {args.input} --response-file {response_profile_path} "
                  f"--output {column_roles_path}\n\n"
                  f"Либо укажите --api-base, чтобы этот шаг тоже выполнился автоматически.\n"
                  f"После этого запустите эту же команду run_pipeline.py ещё раз.", file=sys.stderr)
            sys.exit(1)

    roles = load_column_roles(column_roles_path)
    print(f"Загружены роли колонок: {roles}", file=sys.stderr)

    required = ["metric_name", "date", "fact_value"]
    missing_roles = [r for r in required if r not in roles]
    if missing_roles:
        print(f"Ошибка: в '{column_roles_path}' не хватает ролей: {missing_roles}. "
              f"Проверьте/поправьте этот CSV вручную и запустите снова.", file=sys.stderr)
        sys.exit(1)

    metric_col = roles["metric_name"]
    date_col = roles["date"]
    value_col = roles["fact_value"]
    unit_col = roles.get("unit")

    # ── Связи между показателями ──
    cmd = [py, "find_metric_links.py", "--input", args.input, "--column", metric_col,
           "--output", links_path, "--model", args.embed_model]
    if unit_col:
        cmd += ["--group-column", unit_col]
    if args.sep:
        cmd += ["--sep", args.sep]
    run_step(f"Шаг 1: поиск связей между показателями для '{source_name}' (find_metric_links.py)", cmd)

    # ── Аномалии ──
    if args.anomaly_method == "chronos":
        script = "find_chronos_anomalies.py"
        extra = ["--model", args.chronos_model,
                 "--context-length", str(args.context_length),
                 "--check-last-n", str(args.check_last_n)]
    else:
        script = "find_var_anomalies.py"
        extra = []

    cmd = [py, script, "--input", args.input,
           "--metric-column", metric_col, "--date-column", date_col, "--value-column", value_col,
           "--links-file", links_path, "--output", anomalies_path] + extra
    if unit_col:
        cmd += ["--unit-column", unit_col]
    if args.sep:
        cmd += ["--sep", args.sep]
    run_step(f"Шаг 2: поиск аномалий для '{source_name}' ({script})", cmd)

    # ── Бриф ──
    if args.api_base:
        cmd = [py, "generate_brief.py", "--anomalies", anomalies_path, "--links", links_path,
               "--output", brief_path, "--api-base", args.api_base, "--model-name", args.model_name]
        if args.api_key:
            cmd += ["--api-key", args.api_key]
        run_step(f"Шаг 3: генерация брифа для '{source_name}' напрямую через API (generate_brief.py)", cmd)

        print(f"\n{'='*70}\nГОТОВО — весь пайплайн для '{source_name}' выполнен автоматически.\n{'='*70}",
              file=sys.stderr)
        print(f"Папка результатов: {output_dir}", file=sys.stderr)
        print(f"Итоговый бриф: {brief_path}", file=sys.stderr)
    else:
        cmd = [py, "generate_brief.py", "--anomalies", anomalies_path, "--links", links_path,
               "--output", brief_path, "--dry-run", "--save-prompt", prompt_path]
        run_step(f"Шаг 3: сборка промпта для брифа для '{source_name}' (generate_brief.py --dry-run)", cmd)

        print(f"\n{'='*70}\nАвтоматическая часть для '{source_name}' завершена.\n{'='*70}", file=sys.stderr)
        print(f"Папка результатов: {output_dir}", file=sys.stderr)
        print(f"\nОсталось руками:\n"
              f"  1. Откройте '{prompt_path}', скопируйте в чат вашей LLM\n"
              f"  2. Ответ модели сохраните в {response_brief_path}\n"
              f"  3. Запустите:\n"
              f"     python generate_brief.py --anomalies {anomalies_path} --links {links_path} "
              f"--output {brief_path} --response-file {response_brief_path}\n", file=sys.stderr)


if __name__ == "__main__":
    main()
